#!/bin/sh

# A non-interactive shell -- ssh "host command", or anything not started
# from a login shell -- does not inherit the firmware's PATH, so dirname,
# wc, grep and the unit's own binaries are simply absent and this script
# fails in confusing ways partway through. Set it before any external
# command runs, including the dirname below.
PATH=/proc/boot:/bin:/usr/bin:/usr/sbin:/sbin:/mnt/app/armle/bin:/mnt/app/armle/sbin:/mnt/app/armle/usr/bin:/mnt/app/armle/usr/sbin:$PATH
export PATH

# Install the preload environment into the supervisor-owned GAL child.
# This script never launches a second GAL process.

set -eu

CARD_ROOT=`cd "\`dirname "$0"\`" && pwd`
SYSTEM_MOUNT=/mnt/system
TARGET_CONFIG=$SYSTEM_MOUNT/etc/eso/production/smartphone_integrator.json
PERSISTENT_BACKUP=$TARGET_CONFIG.gal-dualscreen.original
JSONLINT=/mnt/app/eso/bin/jsonlint
# Match the QNX login/startup loader path. In particular, libiplcommon.so,
# libosal.so, and libutil.so are supplied by /lib, not /mnt/app/eso/lib.
VALIDATOR_LD_LIBRARY_PATH=/proc/boot:/lib:/lib/dll:/usr/lib:/mnt/app/root/lib-target:/mnt/app/usr/lib:/mnt/app/armle/lib:/mnt/app/armle/lib/dll:/mnt/app/armle/usr/lib:/eso/lib:/mnt/app/eso/lib
BACKUP_DIR="$CARD_ROOT/backups"
ORIGINAL="$BACKUP_DIR/smartphone_integrator.json.original"
LOG_DIR="$CARD_ROOT/logs"
DPI=140
DEBUG=0
SECOND_SINK=1
INJECT_META=1
AAP_MINOR=
CLUSTER_INPUT=1
OUTPUT=withhold
DISPLAYABLE=
LOG_PATH_REQUESTED=
STREAM=1
SYSTEM_WRITABLE=0
SYSTEM_TEMP=
KEEP_TBT=0
KEEP_NAVIGNORE=0
CARPLAY=1
# The CarPlay map: harman-f's cluster-stream hook (in libcarplay_cluster.so)
# patches functions of this exact CarPlay library, so it is installed only on
# a unit whose libairplay.so has this size (SHA-256 193a4fd9...46b5 on MU1440
# and MU1367). The hook also checks the function prologues itself and leaves
# CarPlay stock on a mismatch.
# Resolved below over the same folders the collector uses: a unit that keeps
# it only at /eso/lib would otherwise be reported as having no CarPlay at all.
AIRPLAY_LIB=/mnt/app/eso/lib/libairplay.so
AIRPLAY_SIZE=703688
# 694088: the build on the Audi A6/A7 C7.5 (K3663) and US P3662, car-tested
# on three A7s and a US Golf with CLUSTERMAP_CARPLAY_TRIAL before it was
# accepted here (#68, #10).
AIRPLAY_SIZE_2=694088
PROFILES=$CARD_ROOT/profiles.conf
CARPLAY_PRELOAD=/mnt/app/eso/lib/gal_dualscreen/libcarplay_cluster.so
CARPLAY_OK=0

# The preload target lives on the internal /mnt/app partition instead of the
# SD card. The SD card mounts read-only again on every fresh boot unless
# something remounts it before GAL starts; unlike the hook's own log path,
# there is no automatic fallback for a missing LD_PRELOAD target -- the
# dynamic linker just silently proceeds without it, so if the SD card is not
# yet mounted at the exact moment smartphone_integrator launches GAL, the
# hook never loads at all, with no error anywhere. See lib_app_mount.sh
# (shared with disable_hook.sh) for the path constants and why /eso/lib
# was chosen over /navigation.
if [ -f "$CARD_ROOT/scripts/lib_app_mount.sh" ]; then
    . "$CARD_ROOT/scripts/lib_app_mount.sh"
elif [ -f "$CARD_ROOT/lib_app_mount.sh" ]; then
    . "$CARD_ROOT/lib_app_mount.sh"
else
    echo "ERROR: lib_app_mount.sh not found in $CARD_ROOT" >&2
    exit 1
fi

if [ ! -r "$CARD_ROOT/scripts/lib_unit.sh" ] || [ ! -r "$PROFILES" ] || \
   [ ! -r "$CARD_ROOT/scripts/lib_cluster_frame.sh" ]; then
    echo "ERROR: scripts/lib_unit.sh, lib_cluster_frame.sh or profiles.conf not found in $CARD_ROOT" >&2
    exit 1
fi
. "$CARD_ROOT/scripts/lib_unit.sh"
. "$CARD_ROOT/scripts/lib_cluster_frame.sh"

finish()
{
    if [ "$SYSTEM_WRITABLE" -eq 1 ]; then
        if [ -n "$SYSTEM_TEMP" ]; then
            rm -f "$SYSTEM_TEMP" 2>/dev/null || true
            SYSTEM_TEMP=
        fi
        mount -ur "$SYSTEM_MOUNT" 2>/dev/null || true
        SYSTEM_WRITABLE=0
    fi
    app_mount_finish
}

trap finish 0 1 2 15

# Size of a file in bytes, or nothing when it is not there. "wc -c < file
# 2>/dev/null" still lets the shell print "cannot open" for a missing file
# (#100, #115 read it as a failed install), and under set -e a failing
# command in an assignment ends the script, so this always returns 0.
file_size()
{
    if [ -r "$1" ]; then wc -c < "$1" | sed 's/ //g'; fi
    return 0
}

usage()
{
    echo "Usage: $0 [--dpi NUMBER] [--debug|--no-debug]   (debug logging is off unless --debug)"
    echo "          [--no-second-sink] [--no-inject-meta] [--aap-minor N]"
    echo "          [--cluster-input]"
    echo "          [--output MODE] [--displayable N] [--log PATH]"
    echo
    echo "  Most settings come from a config FILE, which has no entry limit:"
    echo "  ClusterMap/gal_dualscreen.conf on the SD card, copied to the unit"
    echo "  by this script. Options given here are injected into the"
    echo "  environment and override the file."
    echo
    echo "  --keep-turn-by-turn  leave adi961's VCAndroidAuto.jar loaded. By"
    echo "                    default the installer removes its start-up line,"
    echo "                    because the cluster map fails when a route starts"
    echo "                    while that jar is active."
    echo "  --no-navignore    do not add the NavActiveIgnore patch when it is missing"
    echo "  --no-carplay      install the Android Auto map only, not the CarPlay map"
    echo "  --no-second-sink  register no second video service"
    echo "  --no-inject-meta  write no display_id/display_type fields"
    echo
    echo "  Bisect switches for the SERVICE_DISCOVERY_MISSING result: the"
    echo "  phone stopped answering discovery when the hook did BOTH. Run"
    echo "  each alone to find which the phone objects to."
    echo
    echo "  --aap-minor N     advertise AAP 1.N instead of the stock 1.2."
    echo "                    DHU negotiates 1.7 and gets a working cluster."
    echo "                    Risky: claims protocol this receiver does not"
    echo "                    implement. Verify Android Auto still works."
    echo
    echo "  --cluster-input   also advertise an InputSourceService for the"
    echo "                    cluster (display id 1). Proven necessary in a"
    echo "                    DHU subtractive test: removing it from a"
    echo "                    working two-display session stops the phone"
    echo "                    responding. Pair this with --aap-minor 7."
    echo
    echo "  --output MODE     what to do with the secondary sink's video:"
    echo "                      gal       forward to GAL. Reconfigures the one"
    echo "                                shared renderer and blanks the main"
    echo "                                screen. Stock path."
    echo "                      withhold  do not forward, do not decode. Frames"
    echo "                                still arrive and are counted; main"
    echo "                                screen untouched."
    echo "                      own       decode the frames ourselves into a"
    echo "                                private NvSS instance on the cluster"
    echo "                                displayable. Main screen untouched."
    echo "                      own-ack   NOT currently available for the"
    echo "                                secondary sink -- falls back to own."
    echo "                                (as own, but GAL is still told playback"
    echo "                                started, with the handler's renderer"
    echo "                                job stubbed out via a private vtable."
    echo "                    Default gal. Use own."
    echo "  --log PATH        write the hook log here. Omitted by default so"
    echo "                    the environment array stays short; the hook then"
    echo "                    uses its built-in path and falls back to"
    echo "                    /tmp/gal_dualscreen.log, which the status scripts"
    echo "                    search for anyway."
    echo "  --displayable N   cluster displayable to decode onto. Default 3;"
    echo "                    33 is the stock Kombi map window, already 800x480"
    echo "                    and already routed to the cluster by context 70."
    echo "  --no-secondary-render  alias for --output withhold. Do not forward"
    echo "                    playbackStart to GAL. GAL owns one renderer, so"
    echo "                    forwarding it blanks the main screen; withholding"
    echo "                    keeps the main screen and still counts frames."
    echo
    echo "  The cluster map window's size is read from the display manager at"
    echo "  install time. Where it is not 800x480, the phone is asked to leave"
    echo "  margins so its map has that shape, and the player fills the window."
}

while [ $# -gt 0 ]; do
    case "$1" in
        --dpi)
            [ $# -ge 2 ] || { usage >&2; exit 2; }
            DPI=$2
            shift 2
            ;;
        --aap-minor)
            [ $# -ge 2 ] || { usage >&2; exit 2; }
            AAP_MINOR=$2
            case "$AAP_MINOR" in ''|*[!0-9]*) echo "--aap-minor needs a number" >&2; exit 2 ;; esac
            shift 2
            ;;
        --cluster-input) CLUSTER_INPUT=1; shift ;;
        --no-cluster-input) CLUSTER_INPUT=0; shift ;;
        --output)
            [ $# -ge 2 ] || { usage >&2; exit 2; }
            OUTPUT="$2"
            case "$OUTPUT" in
                own-ack)
                    # Accepted rather than rejected, because the hook falls
                    # back safely and the mode becomes real once the
                    # secondary gets a proper CVideoSinkCallbackHandler.
                    # But it must not look like it is doing something.
                    echo "NOTE: own-ack is not available for the secondary sink." >&2
                    echo "      This hook writes a CVideoSinkImpl into sink+0x38, so" >&2
                    echo "      playbackStart there dispatches to that class's slot 6" >&2
                    echo "      (ackFrames), not the callback handler's playbackStart" >&2
                    echo "      that own-ack stubs. The hook will refuse the patch and" >&2
                    echo "      run as 'own'. Use --output own." >&2
                    ;;
                own)
                    # The mode's SHAPE is right -- withhold from GAL,
                    # decode ourselves, ack ourselves -- but its decoder
                    # is NvSS, and the car proved on 2026-08-22 that a
                    # second NvSS stream cannot render: it dies at
                    # NvMediaVideoMixerBindOutput because GAL owns the
                    # only physical output. Accepted rather than rejected,
                    # because it becomes correct the moment the decoder is
                    # rebuilt on NvMedia + a KD stream, and the frame
                    # extraction and acking underneath it are already
                    # right. But nobody should spend a boot on it unaware.
                    echo "NOTE: --output own cannot display anything yet." >&2
                    echo "      Its decoder is NvSS, and a second NvSS stream cannot" >&2
                    echo "      render on this unit -- it fails at" >&2
                    echo "      NvMediaVideoMixerBindOutput because GAL owns the only" >&2
                    echo "      physical output. See the NvSS experiment in README.md." >&2
                    echo "      Expect own.open to succeed, a few own.decode lines, then" >&2
                    echo "      nothing on the cluster. The useful on-car test right now" >&2
                    echo "      is ./nvmedia_probe, which needs no install and no reboot." >&2
                    ;;
                gal|withhold) ;;
                *) echo "--output must be gal, withhold, own or own-ack" >&2; exit 2 ;;
            esac
            shift 2 ;;
        --log)
            [ $# -ge 2 ] || { usage >&2; exit 2; }
            HOOK_LOG_PATH="$2"; LOG_PATH_REQUESTED=1
            shift 2 ;;
        --displayable)
            [ $# -ge 2 ] || { usage >&2; exit 2; }
            DISPLAYABLE="$2"
            case "$DISPLAYABLE" in ''|*[!0-9]*) echo "--displayable needs a number" >&2; exit 2 ;; esac
            shift 2 ;;
        --stream) STREAM=1; shift ;;
        --no-stream) STREAM=0; shift ;;
        # Documented as "alias for --output withhold", and now implemented as
        # exactly that. It used to emit GAL_DUALSCREEN_SECONDARY_RENDER=0, a key
        # the hook stopped reading when the NvSS/own-render paths were removed --
        # so the flag spent one of the ~10 environment slots to say nothing.
        --no-secondary-render) OUTPUT=withhold; shift ;;
        --no-second-sink) SECOND_SINK=0; shift ;;
        --no-inject-meta) INJECT_META=0; shift ;;
        --debug) DEBUG=1; shift ;;
        --no-debug) DEBUG=0; shift ;;
        --keep-turn-by-turn) KEEP_TBT=1; shift ;;
        --no-navignore) KEEP_NAVIGNORE=1; shift ;;
        --no-carplay) CARPLAY=0; shift ;;
        -h|--help) usage; exit 0 ;;
        *) echo "Unknown option: $1" >&2; usage >&2; exit 2 ;;
    esac
done

case "$DPI" in
    ''|*[!0-9]*) echo "DPI must be a positive integer" >&2; exit 2 ;;
esac
[ "$DPI" -gt 0 ] || { echo "DPI must be greater than zero" >&2; exit 2; }
[ -r "$CARD_ROOT/libgal_hook.so" ] || {
    echo "Missing $CARD_ROOT/libgal_hook.so" >&2
    exit 1
}
[ -r "$TARGET_CONFIG" ] || {
    echo "Missing persistent supervisor config: $TARGET_CONFIG" >&2
    exit 1
}
[ -x "$JSONLINT" ] || {
    echo "Required firmware validator is missing: $JSONLINT" >&2
    exit 1
}
LD_LIBRARY_PATH="$VALIDATOR_LD_LIBRARY_PATH" "$JSONLINT" --file "$TARGET_CONFIG" || {
    echo "jsonlint could not validate the existing persistent supervisor config" >&2
    echo "No file has been modified" >&2
    exit 1
}

mkdir -p "$BACKUP_DIR" "$LOG_DIR" || {
    echo "Cannot create $BACKUP_DIR / $LOG_DIR under $CARD_ROOT" >&2
    exit 1
}
# mkdir -p SUCCEEDS on an already-existing directory even when the
# filesystem is mounted read-only, so it cannot detect the SD card's
# default state after a power cycle. Relying on it meant the install got
# as far as staging the preload, then failed on the first real write with
# "cannot create ...: Read-only file system" and reported the misleading
# "Could not locate children.gal.envs" -- pointing at the config's
# structure rather than at the mount. Probe with an actual write, which
# is the thing that has to work, and fail here with the real reason.
WRITE_PROBE="$LOG_DIR/.write_probe.$$"
if ! : > "$WRITE_PROBE" 2>/dev/null; then
    echo "Cannot write $CARD_ROOT -- it is mounted read-only." >&2
    echo "The SD card returns to read-only on every boot; run this first:" >&2
    echo "    mount -uw $CARD_ROOT" >&2
    exit 1
fi
rm -f "$WRITE_PROBE"

# Stage the preload target on the internal partition before touching the
# persistent supervisor config at all: if this fails, nothing has been
# modified yet, matching the fail-closed pattern used throughout this
# script. Always copy fresh rather than trusting an existing copy, so an
# updated libgal_hook.so on the SD card is never silently ignored.
#
# On a repeat install, PRELOAD_SO_REAL is not a fresh file -- it is the
# exact path the live LD_PRELOAD alias already resolves to, in active use
# by whatever GAL session is currently running. Stage to a temp name in
# the same directory, verify it, and only then atomically rename it onto
# the live path -- the same stage-then-atomic-rename shape used for
# TARGET_CONFIG below -- so an interrupted or partial copy (disk full,
# power loss mid-write) can never leave that live, already-relied-upon
# file half-written. A direct cp onto the live path could.
mount -uw "$APP_MOUNT" 2>/dev/null || {
    echo "Cannot remount $APP_MOUNT read-write" >&2
    exit 1
}
APP_WRITABLE=1
mkdir -p "$PRELOAD_WRITE_DIR" || {
    echo "Cannot create $PRELOAD_WRITE_DIR" >&2
    exit 1
}
# Belt-and-braces alongside the file-level chmod below: mkdir -p honors
# umask for the directory's own mode bits, and this directory needs to
# stay traversable regardless of the invoking shell's umask.
chmod 755 "$PRELOAD_WRITE_DIR" 2>/dev/null || true
PRELOAD_SO_TEMP="$PRELOAD_WRITE_DIR/libgal_hook.so.new.$$"
cp "$CARD_ROOT/libgal_hook.so" "$PRELOAD_SO_TEMP" || {
    rm -f "$PRELOAD_SO_TEMP"
    echo "Could not stage libgal_hook.so to $PRELOAD_SO_TEMP" >&2
    exit 1
}
chmod 755 "$PRELOAD_SO_TEMP" 2>/dev/null || true
# Byte-for-byte where available: a same-size but corrupted copy would pass
# a size-only check. This unit's firmware image ships neither cmp nor
# diff at all -- confirmed against the full extracted firmware tree, not
# just a PATH gap on this shell -- so probe for cmp and fall back to the
# size-only comparison this project used before cmp was assumed available,
# rather than hard-failing every install on a tool this target never had.
if command -v cmp >/dev/null 2>&1; then
    cmp -s "$CARD_ROOT/libgal_hook.so" "$PRELOAD_SO_TEMP" || {
        rm -f "$PRELOAD_SO_TEMP"
        echo "Staged libgal_hook.so does not match $CARD_ROOT/libgal_hook.so" >&2
        exit 1
    }
else
    SRC_SIZE=`wc -c < "$CARD_ROOT/libgal_hook.so"` || {
        rm -f "$PRELOAD_SO_TEMP"
        echo "Could not read size of $CARD_ROOT/libgal_hook.so" >&2
        exit 1
    }
    DST_SIZE=`wc -c < "$PRELOAD_SO_TEMP"` || {
        rm -f "$PRELOAD_SO_TEMP"
        echo "Could not read size of staged $PRELOAD_SO_TEMP" >&2
        exit 1
    }
    [ "$SRC_SIZE" -eq "$DST_SIZE" ] || {
        rm -f "$PRELOAD_SO_TEMP"
        echo "Staged libgal_hook.so size ($DST_SIZE) does not match $CARD_ROOT/libgal_hook.so ($SRC_SIZE)" >&2
        exit 1
    }
    echo "Note: cmp is not available on this unit; verified staged copy by size only."
fi
mv "$PRELOAD_SO_TEMP" "$PRELOAD_SO_REAL" || {
    rm -f "$PRELOAD_SO_TEMP"
    echo "Could not atomically install $PRELOAD_SO_REAL" >&2
    exit 1
}
# Confirm the short /eso alias actually resolves to what was just written,
# not just that the write under /mnt/app/eso succeeded -- catches a wrong
# assumption about the /eso alias before it ever reaches the persistent
# config, rather than silently deploying a dead LD_PRELOAD path.
[ -r "$PRELOAD_SO_ALIAS" ] || {
    echo "$PRELOAD_SO_ALIAS is not readable through the short alias path" >&2
    echo "Wrote to $PRELOAD_WRITE_DIR but /eso does not resolve to it as expected" >&2
    exit 1
}
# Install libdmdt_flush.so interposer to PRELOAD_WRITE_DIR and /mnt/app/eso/lib
if [ -r "$CARD_ROOT/lib/libdmdt_flush.so" ]; then
    cp "$CARD_ROOT/lib/libdmdt_flush.so" "$PRELOAD_WRITE_DIR/libdmdt_flush.so" 2>/dev/null || true
    chmod 755 "$PRELOAD_WRITE_DIR/libdmdt_flush.so" 2>/dev/null || true
    cp "$CARD_ROOT/lib/libdmdt_flush.so" "$APP_MOUNT/eso/lib/libdmdt_flush.so" 2>/dev/null || true
    chmod 755 "$APP_MOUNT/eso/lib/libdmdt_flush.so" 2>/dev/null || true
    echo "Installed dmdt flush interposer to: $PRELOAD_WRITE_DIR/libdmdt_flush.so"
fi

# The profiles the hook matches gal against, and the script the player runs
# when the cockpit's map window is not the size in the settings.
cp "$PROFILES" "$PRELOAD_WRITE_DIR/profiles.conf" && chmod 644 "$PRELOAD_WRITE_DIR/profiles.conf" || {
    echo "Could not copy profiles.conf to $PRELOAD_WRITE_DIR" >&2
    exit 1
}
cp "$CARD_ROOT/scripts/window_fix.sh" "$PRELOAD_WRITE_DIR/window_fix.sh" 2>/dev/null || true
chmod 755 "$PRELOAD_WRITE_DIR/window_fix.sh" 2>/dev/null || true
cp "$CARD_ROOT/scripts/lib_cluster_frame.sh" "$PRELOAD_WRITE_DIR/lib_cluster_frame.sh" 2>/dev/null || true
chmod 644 "$PRELOAD_WRITE_DIR/lib_cluster_frame.sh" 2>/dev/null || true

TRAIN=unknown
for f in /net/rcc/dev/shmem/version.txt /dev/shmem/version.txt; do
    if [ -r "$f" ]; then
        TRAIN=`grep "Current train" "$f" | sed 's/Current train = //' | sed -e 's|["'"'"']||g' | sed 's/\r//'`
        break
    fi
done

# The settings owners have tested, by make (profiles.conf): read here, before
# the settings copy, which needs the make's "auto" values; used again below.
unit_make "$PROFILES" "$TRAIN" || :

# Internal copy of the settings file: the hook reads the SD card first and
# falls back to this one, so the tuned values still apply without the card.
# Every setting below is read from this copy, which is written without the
# carriage returns a Windows editor adds: with them none of the installer's
# own readers matched a line, while the hook (which strips them) still did,
# so a CRLF file was half-applied without a word.
#
# The owner's own lines from the last install are put back where this card
# still has the shipped default (scripts/lib_keep_settings.sh), with one
# exception: on the SAME package as the last install, a setting whose line
# on the card has changed since that install is the owner's edit and is used
# as it is, also when the edit was putting it back to the shipped value
# (#19: FRAME_SCALE commented out on the card, yet 135 came back each time).
CONF_COPY="$PRELOAD_WRITE_DIR/gal_dualscreen.conf"
OWNER_SAVED="$PRELOAD_WRITE_DIR/gal_dualscreen.owner.conf"
CARD_LAST="$PRELOAD_WRITE_DIR/gal_dualscreen.card.conf"
CONF_DEFAULT="$CARD_ROOT/scripts/gal_dualscreen.default.conf"
PKG_SAVED="$PRELOAD_WRITE_DIR/package_version.txt"
PKG_NOW=`head -1 "$CARD_ROOT/scripts/package_version.txt" 2>/dev/null || :`
PKG_LAST=`head -1 "$PKG_SAVED" 2>/dev/null || :`
CARD_SAVED_NEW=
if [ -r "$CARD_ROOT/gal_dualscreen.conf" ]; then
    if awk '{ sub(/\r$/, ""); print }' "$CARD_ROOT/gal_dualscreen.conf" > "$CONF_COPY.card" 2>/dev/null &&
       [ -s "$CONF_COPY.card" ]; then
        :
    else
        cp "$CARD_ROOT/gal_dualscreen.conf" "$CONF_COPY.card" 2>/dev/null || true
    fi
    KEEP_SETTINGS=`sed -n 's/^CLUSTERMAP_KEEP_SETTINGS=\([01]\)[ 	]*$/\1/p' "$CONF_COPY.card" 2>/dev/null | tail -1`
    KEEP_FROM=
    if [ "$KEEP_SETTINGS" != 0 ] && [ -r "$CONF_DEFAULT" ] && [ -r "$CARD_ROOT/scripts/lib_keep_settings.sh" ] &&
       [ -r "$OWNER_SAVED" ]; then
        . "$CARD_ROOT/scripts/lib_keep_settings.sh"
        if [ -n "$PKG_NOW" ] && [ "$PKG_NOW" = "$PKG_LAST" ] && [ -r "$CARD_LAST" ]; then
            keep_unedited "$OWNER_SAVED" "$CONF_COPY.card" "$CARD_LAST" > /tmp/clustermap_owner_prev.conf 2>/dev/null &&
                KEEP_FROM=saved || :
        else
            cp "$OWNER_SAVED" /tmp/clustermap_owner_prev.conf 2>/dev/null && KEEP_FROM=saved || :
        fi
    elif [ "$KEEP_SETTINGS" != 0 ] && [ ! -r "$OWNER_SAVED" ] && [ -r "$CONF_COPY" ]; then
        # Installed by a release that saved no owner lines (v1.1.1, beta18 or
        # older). Its copy cannot tell the owner's lines from the ones that
        # installer wrote or shipped, so nothing is carried over.
        echo "Settings: the previous install was from an older release; its settings are not carried over. This card's gal_dualscreen.conf is used."
    fi
    # The card's file as it is now, for the comparison at the next install.
    # Moved into place only when this install has finished.
    cp "$CONF_COPY.card" "$CARD_LAST.new" 2>/dev/null && CARD_SAVED_NEW=1
    mv "$CONF_COPY.card" "$CONF_COPY" 2>/dev/null || cp "$CARD_ROOT/gal_dualscreen.conf" "$CONF_COPY" 2>/dev/null || true
    chmod 644 "$CONF_COPY" 2>/dev/null || true
    echo "Installed settings copy: $CONF_COPY"
    if [ -n "$KEEP_FROM" ]; then
        KEPT=`keep_apply "$CONF_COPY" /tmp/clustermap_owner_prev.conf "$CONF_DEFAULT"` || {
            KEPT=; echo "WARNING: could not carry over your previous settings; using the card's as they are." >&2; }
        if [ -n "$KEPT" ]; then
            echo "Kept from your previous install (change them on the card to override, or CLUSTERMAP_KEEP_SETTINGS=0 for a clean install):"
            echo "$KEPT" | sed 's/^/  /'
        fi
    elif [ "$KEEP_SETTINGS" = 0 ]; then
        echo "CLUSTERMAP_KEEP_SETTINGS=0: installed the card's settings only."
    fi
    rm -f /tmp/clustermap_owner_prev.conf 2>/dev/null
    # The owner's lines for the next install, before this installer adds its own.
    if [ -r "$CONF_DEFAULT" ] && [ -r "$CARD_ROOT/scripts/lib_keep_settings.sh" ]; then
        . "$CARD_ROOT/scripts/lib_keep_settings.sh"
        keep_owner_lines "$CONF_COPY" "$CONF_DEFAULT" > "$OWNER_SAVED.new" 2>/dev/null &&
            mv "$OWNER_SAVED.new" "$OWNER_SAVED" 2>/dev/null || rm -f "$OWNER_SAVED.new" 2>/dev/null
    fi
else
    echo "NOTE: no gal_dualscreen.conf beside this script; the hook will run on built-in defaults."
fi
# CLUSTERMAP_KEEP_ARROWS=1: keep the turn-arrows jar with the map, adding it
# when missing. On SEAT the two work together; on VW the map goes blank when
# a route starts.
WITH_ARROWS=0
if [ "`sed -n 's/^CLUSTERMAP_KEEP_ARROWS=\([01]\)[ 	]*$/\1/p' "$PRELOAD_WRITE_DIR/gal_dualscreen.conf" 2>/dev/null | tail -1`" = 1 ]; then
    WITH_ARROWS=1; KEEP_TBT=1
fi
# CLUSTERMAP_CARPLAY_TRIAL=<size in bytes>: install the CarPlay map on a unit
# whose libairplay.so is a different build from the one the hook was written
# against, for testing. This is the CarPlay equivalent of GAL_PROFILE_TRIAL.
#
# It is a weaker gate than it looks, in the safe direction: the hook attaches
# by exported symbol name (AirPlayReceiverSessionStart and nine others), not
# by address, and it compares the first eight bytes of every function it
# trampolines before touching it -- "prologue mismatch" in its log, and
# CarPlay stays stock. That is not proof the build fits: 857735 (Audi K3346,
# VWG11 K3342) passes both checks with 26 AirPlay functions changed, Setup
# among them. So nothing suggests this any more; it stays for a developer
# with a build they have checked. Asked for in #10 (US P3662, which worked).
AIRPLAY_TRIAL=`sed -n 's/^CLUSTERMAP_CARPLAY_TRIAL=\([0-9]*\)[ 	]*$/\1/p' \
    "$PRELOAD_WRITE_DIR/gal_dualscreen.conf" 2>/dev/null | tail -1`
for d in /mnt/app/eso/lib /eso/lib /mnt/app/armle/lib /mnt/app/usr/lib /mnt/app/root/lib-target; do
    if [ -r "$d/libairplay.so" ]; then AIRPLAY_LIB="$d/libairplay.so"; break; fi
done
AIRPLAY_NOW=`file_size "$AIRPLAY_LIB"`
AIRPLAY_ALLOWED=0
[ "$AIRPLAY_NOW" = "$AIRPLAY_SIZE" ] && AIRPLAY_ALLOWED=1
[ "$AIRPLAY_NOW" = "$AIRPLAY_SIZE_2" ] && AIRPLAY_ALLOWED=1
[ -n "$AIRPLAY_TRIAL" ] && [ "$AIRPLAY_NOW" = "$AIRPLAY_TRIAL" ] && AIRPLAY_ALLOWED=1
# A build that is car-tested on this train only: a "carplay<size>" word on its
# train line in profiles.conf (857735 on VW K3342: #62, #111; the same size
# gave a black centre screen on an Audi K3346, #14, so it is not accepted
# everywhere).
AIRPLAY_BY_TRAIN=0
if [ -n "$AIRPLAY_NOW" ] && train_has "$PROFILES" "$TRAIN" "carplay$AIRPLAY_NOW"; then
    AIRPLAY_ALLOWED=1
    AIRPLAY_BY_TRAIN=1
fi
# CLUSTERMAP_CARPLAY=0: the Android Auto map only. CarPlay's preload and
# firewall rule are left out, for wireless adapters that do not get along
# with them (#55, #56). The same as --no-carplay, from the card.
if [ "`sed -n 's/^CLUSTERMAP_CARPLAY=\([01]\)[ 	]*$/\1/p' "$PRELOAD_WRITE_DIR/gal_dualscreen.conf" 2>/dev/null | tail -1`" = 0 ]; then
    CARPLAY=0
fi

# The settings owners have tested, by make (unit_make above): the cockpit
# map window, then DPI and insets. Used for "auto" in gal_dualscreen.conf
# (#41) and, for the window, when the display manager does not list it (#15,
# #19: a SEAT and a Skoda drew stripes in an 800x480 window). Values:
# docs/Install.md.

# The cluster map window. The cluster's encoder expects the window it shows
# to be this size; an 800x480 window on a cluster whose map window is, say,
# 1010x376 arrives as stripes (SEAT P4708, issue #4). So the player opens its
# window at the stock Kombi map window's size: Android Auto's 800x480 frame
# is drawn into it at its own shape, and CarPlay is asked for that size
# outright. dmdt gd prints one line per window: ID, type, "W x H", buffers,
# name; 33 is the stock Kombi map.
MAP_SIZE=`( cd /eso && LD_PRELOAD="$PRELOAD_WRITE_DIR/libdmdt_flush.so" \
    LD_LIBRARY_PATH=/eso/lib:/lib:/usr/lib IPL_CONFIG_DIR=/etc/eso/production \
    ./bin/apps/dmdt gd ) 2>/dev/null | awk '
    $1 == 33 {
        for (i = 2; i < NF; i++) if ($i == "x") { print $(i - 1) "x" $(i + 1); exit }
    }'`
# A GAL_PLAYER_WINDOW line in the card's settings is used only when the
# display manager does not list the window (#19: a SEAT that never reported
# its 1010x376, with its own map on the cockpit at every install).
MAP_SET=`sed -n 's/^GAL_PLAYER_WINDOW=\([0-9]*x[0-9]*\)[ 	]*$/\1/p' \
    "$PRELOAD_WRITE_DIR/gal_dualscreen.conf" 2>/dev/null | tail -1`
MAP_FROM="display manager"
MAP_GUESSED=
if [ -z "$MAP_SIZE" ] && [ -n "$MAP_SET" ]; then
    MAP_SIZE=$MAP_SET
    MAP_FROM="GAL_PLAYER_WINDOW in gal_dualscreen.conf"
fi
# The window the player found on this cockpit at an earlier start
# (window_fix.sh saves it; #95: a Tiguan's 1010x376 never listed at install).
MAP_SEEN=`sed -n 's/^\([0-9]*x[0-9]*\)[ 	]*$/\1/p' "$PRELOAD_WRITE_DIR/player_window" 2>/dev/null | tail -1`
if [ -z "$MAP_SIZE" ] && [ -n "$MAP_SEEN" ]; then
    MAP_SIZE=$MAP_SEEN
    MAP_FROM="player's last start on this cockpit"
fi
if [ -z "$MAP_SIZE" ] && [ -n "$CAR_WINDOW" ]; then
    MAP_SIZE=$CAR_WINDOW
    MAP_FROM="usual size on $CAR_MAKE; the display manager did not list it"
    MAP_GUESSED=1
fi
MAP_W=`echo "$MAP_SIZE" | sed -n 's/^\([0-9][0-9]*\)x[0-9][0-9]*$/\1/p'`
MAP_H=`echo "$MAP_SIZE" | sed -n 's/^[0-9][0-9]*x\([0-9][0-9]*\)$/\1/p'`
if [ -n "$MAP_W" ] && [ -n "$MAP_H" ] && [ "$MAP_W" -ge 320 ] && [ "$MAP_W" -le 1920 ] && \
   [ "$MAP_H" -ge 160 ] && [ "$MAP_H" -le 1080 ]; then
    echo "Cluster map window: ${MAP_W}x${MAP_H} (from the $MAP_FROM)"
    if [ -n "$MAP_GUESSED" ]; then
        # #52: a VW cockpit with a 1010x376 window took the 800x480 guess.
        echo "  This size is a guess, and not every $CAR_MAKE cockpit has it. If the map"
        echo "  does not appear, put the cockpit in map view with the car's own"
        echo "  navigation and install again, or set GAL_PLAYER_WINDOW in"
        echo "  gal_dualscreen.conf (dmdt_gd.txt in Save logs lists window 33)."
    fi
else
    MAP_W=800; MAP_H=480
    echo "Cluster map window: not reported by the display manager; using 800x480."
    echo "  The stock map window is only listed once the cockpit has shown its"
    echo "  own map. If your cockpit map is not 800x480, the picture can arrive"
    echo "  as stripes or the wrong shape. To get the right size: put the"
    echo "  cockpit in map view with the car's own navigation, then run this"
    echo "  install again. If it still is not listed, set the size yourself in"
    echo "  gal_dualscreen.conf, e.g. GAL_PLAYER_WINDOW=1010x376 on SEAT and Skoda."
fi
# Standard Android Auto uses 800x480. Optional 720p and 1080p test modes use
# margins that leave the cockpit window's pixels visible.
# The settled values for this make and this window, when a make line names
# the window (VW 1010x376); otherwise those of the first make line stay.
unit_make_window "$PROFILES" "$TRAIN" "${MAP_W}x${MAP_H}" || :
# auto (the shipped value): the make line's fullframe word; 0 or 1 as written.
FULL_FRAME=`sed -n 's/^CLUSTERMAP_FULL_FRAME=\([01a-z]*\)[ 	]*$/\1/p' \
    "$PRELOAD_WRITE_DIR/gal_dualscreen.conf" 2>/dev/null | tail -1`
if [ "$FULL_FRAME" = auto ]; then
    FULL_FRAME=${CAR_FULLFRAME:-0}
    if [ "$FULL_FRAME" = 1 ]; then
        echo "CLUSTERMAP_FULL_FRAME: on, the settled value for $CAR_MAKE ${MAP_W}x${MAP_H} (0 in gal_dualscreen.conf, or Sharper map OFF in the green menu, turns it off)."
    fi
fi
[ "$FULL_FRAME" = 1 ] || FULL_FRAME=0
HD720=`sed -n 's/^CLUSTERMAP_720P=\([01]\)[ 	]*$/\1/p' \
    "$PRELOAD_WRITE_DIR/gal_dualscreen.conf" 2>/dev/null | tail -1`
HD1080=`sed -n 's/^CLUSTERMAP_1080P=\([01]\)[ 	]*$/\1/p' \
    "$PRELOAD_WRITE_DIR/gal_dualscreen.conf" 2>/dev/null | tail -1`
[ "$HD720" = 1 ] || HD720=0
[ "$HD1080" = 1 ] || HD1080=0
if [ "$HD1080" = 1 ] && [ "$HD720" = 1 ]; then
    echo "Both high-resolution modes were enabled; using 1080p."
    HD720=0
fi
# The owner's choice is saved as it is even where this window cannot use it:
# when the player finds the real window later, window_fix.sh applies it.
FULL_FRAME_ASKED=$FULL_FRAME
if [ "$FULL_FRAME" = 1 ] && ! frame_full_ok $MAP_W $MAP_H; then
    echo "CLUSTERMAP_FULL_FRAME: the ${MAP_W}x${MAP_H} window is not wider than the frame's 5:3, so it gets no full frame; kept on in case the cockpit's window turns out wider."
    FULL_FRAME=0
fi
# 1080p needs the hardware decoder (software manages about 15 pictures a
# second, #125): hw in the card's file, or auto on a train with hwdecode.
if [ "$HD1080" = 1 ]; then
    HD_DECODER=`sed -n 's/^GAL_PLAYER_DECODER=\([a-z]*\)[ 	]*$/\1/p' "$PRELOAD_WRITE_DIR/gal_dualscreen.conf" 2>/dev/null | head -1`
    if [ "$HD_DECODER" = auto ] && train_has "$PROFILES" "$TRAIN" hwdecode; then HD_DECODER=hw; fi
    if [ "$HD_DECODER" != hw ]; then
        echo "CLUSTERMAP_1080P: needs the hardware decoder (GAL_PLAYER_DECODER=hw); using the standard frame."
        HD1080=0
    fi
fi
if [ "$HD1080" = 1 ] && ! frame_hd_ok "$MAP_W" "$MAP_H" 1920 1080; then
    echo "CLUSTERMAP_1080P: helps only on a window larger than 800x480 that fits in 1920x1080, not ${MAP_W}x${MAP_H}; using the standard frame."
    HD1080=0
fi
if [ "$HD720" = 1 ] && ! frame_hd_ok "$MAP_W" "$MAP_H" 1280 720; then
    echo "CLUSTERMAP_720P: helps only on a window larger than 800x480 that fits in 1280x720, not ${MAP_W}x${MAP_H}; using the standard frame."
    HD720=0
fi
if ! frame_write_conf "$PRELOAD_WRITE_DIR/gal_dualscreen.conf" \
        "$MAP_W" "$MAP_H" "$FULL_FRAME_ASKED" "$HD720" "$HD1080"; then
    if [ "$FULL_FRAME" = 1 ]; then
        echo "WARNING: could not edit the settings copy; CLUSTERMAP_FULL_FRAME ignored, using margins."
    fi
    FULL_FRAME=0
    HD720=0
    HD1080=0
    frame_geometry "$MAP_W" "$MAP_H" 0 0 0
fi
if [ "$FRAME_MODE" = 1080p ] || [ "$FRAME_MODE" = 720p ]; then
    echo "Android Auto: ${FRAME_W}x${FRAME_H} with ${MARGIN_W}x${MARGIN_H} margins, leaving the ${MAP_W}x${MAP_H} cockpit window to show 1:1 (test mode)."
elif [ "$FULL_FRAME" = 1 ]; then
    echo "Android Auto: whole 800x480 frame, pixel aspect ${PIXEL_ASPECT_E4}/10000, stretched to the window (CLUSTERMAP_FULL_FRAME; car-tested only on AMDFX60's Skoda Superb)."
elif [ "$MARGIN_W" -gt 0 ] || [ "$MARGIN_H" -gt 0 ]; then
    echo "Android Auto: 800x480 with ${MARGIN_W}x${MARGIN_H} margins, scaled to fill the window."
fi

# "auto" DPI and insets: the values owners settled on for this make and
# window. A number in the card's file is kept as it is. Rewritten in place
# because the hook keeps the first value it reads for a key.
if [ "${MAP_W}x${MAP_H}" = "$CAR_WINDOW" ]; then
    AUTO_FROM="tested on $CAR_MAKE, ${MAP_W}x${MAP_H}"
else
    CAR_DPI=125; CAR_INSETS=40,40,127,127
    AUTO_FROM="no tested values for this car and window; shipped defaults"
fi
CONF_DPI=`sed -n 's/^GAL_SECONDARY_DPI=\([^ 	]*\)[ 	]*$/\1/p' "$PRELOAD_WRITE_DIR/gal_dualscreen.conf" 2>/dev/null | head -1`
CONF_INSETS=`sed -n 's/^GAL_SECONDARY_INSETS=\([^ 	]*\)[ 	]*$/\1/p' "$PRELOAD_WRITE_DIR/gal_dualscreen.conf" 2>/dev/null | head -1`
if [ "$CONF_DPI" = auto ] || [ "$CONF_INSETS" = auto ]; then
    if sed -e "s/^GAL_SECONDARY_DPI=auto[ 	]*$/GAL_SECONDARY_DPI=$CAR_DPI/" \
           -e "s/^GAL_SECONDARY_INSETS=auto[ 	]*$/GAL_SECONDARY_INSETS=$CAR_INSETS/" \
           "$PRELOAD_WRITE_DIR/gal_dualscreen.conf" > "$PRELOAD_WRITE_DIR/gal_dualscreen.conf.new" &&
       mv "$PRELOAD_WRITE_DIR/gal_dualscreen.conf.new" "$PRELOAD_WRITE_DIR/gal_dualscreen.conf"; then
        :
    else
        rm -f "$PRELOAD_WRITE_DIR/gal_dualscreen.conf.new"
        echo "WARNING: could not fill in the auto settings; the hook uses its built-in values." >&2
    fi
fi
# GAL_PLAYER_DECODER=auto (the shipped value): hw on a train whose line in
# profiles.conf has the "hwdecode" word, sw everywhere else. A line the owner
# wrote as sw or hw, on the card or with the green menu's switch, is not
# touched. If this fails the line stays auto, which the player reads as sw.
CONF_DECODER=`sed -n 's/^GAL_PLAYER_DECODER=\([^ 	]*\)[ 	]*$/\1/p' "$PRELOAD_WRITE_DIR/gal_dualscreen.conf" 2>/dev/null | head -1`
if [ "$CONF_DECODER" = auto ]; then
    if train_has "$PROFILES" "$TRAIN" hwdecode; then AUTO_DECODER=hw; else AUTO_DECODER=sw; fi
    if sed "s/^GAL_PLAYER_DECODER=auto[ 	]*$/GAL_PLAYER_DECODER=$AUTO_DECODER/" "$PRELOAD_WRITE_DIR/gal_dualscreen.conf" \
           > "$PRELOAD_WRITE_DIR/gal_dualscreen.conf.new" &&
       mv "$PRELOAD_WRITE_DIR/gal_dualscreen.conf.new" "$PRELOAD_WRITE_DIR/gal_dualscreen.conf"; then
        if [ "$AUTO_DECODER" = hw ]; then
            echo "Decoder: the unit's own video decoder, the tested default on $TRAIN (GAL_PLAYER_DECODER=sw, or the green menu's Hardware decoder OFF, for software)."
        fi
    else
        rm -f "$PRELOAD_WRITE_DIR/gal_dualscreen.conf.new"
        echo "WARNING: could not fill in the decoder setting; the player uses software." >&2
    fi
fi
# Audi A4 B9 (AUG22) shows its cockpit map in context 72, not 70 (#14). The
# shipped 70 is changed in the installed copy; any other number is kept.
if [ "$CAR_CONTEXT" != 70 ] &&
   grep -q '^GAL_VC_CONTEXT=70[ 	]*$' "$PRELOAD_WRITE_DIR/gal_dualscreen.conf" 2>/dev/null; then
    if sed "s/^GAL_VC_CONTEXT=70[ 	]*$/GAL_VC_CONTEXT=$CAR_CONTEXT/" "$PRELOAD_WRITE_DIR/gal_dualscreen.conf" \
           > "$PRELOAD_WRITE_DIR/gal_dualscreen.conf.new" &&
       mv "$PRELOAD_WRITE_DIR/gal_dualscreen.conf.new" "$PRELOAD_WRITE_DIR/gal_dualscreen.conf"; then
        echo "Cockpit context: $CAR_CONTEXT ($CAR_MAKE)"
    else
        rm -f "$PRELOAD_WRITE_DIR/gal_dualscreen.conf.new"
        echo "WARNING: could not set GAL_VC_CONTEXT=$CAR_CONTEXT; set it in gal_dualscreen.conf." >&2
    fi
fi
[ "$CONF_DPI" = auto ] && echo "Map DPI: $CAR_DPI ($AUTO_FROM)" || echo "Map DPI: ${CONF_DPI:-built-in} (from gal_dualscreen.conf)"
[ "$CONF_INSETS" = auto ] && echo "Map insets: $CAR_INSETS ($AUTO_FROM)" || echo "Map insets: ${CONF_INSETS:-built-in} (from gal_dualscreen.conf)"
# The DPI the hook will actually use, for the summary. --dpi goes into the
# environment, which the hook reads before the conf file, so it wins.
case "$CONF_DPI" in
    auto) EFFECTIVE_DPI=$CAR_DPI ;;
    '')   EFFECTIVE_DPI=built-in ;;
    *)    EFFECTIVE_DPI=$CONF_DPI ;;
esac
[ "$DPI" -ne 140 ] && EFFECTIVE_DPI=$DPI

# An older cluster renderer (OneB1t's VcMOSTRenderMqb: /navigation/
# opengl-render-qnx, started at every boot by a "# QNX VNC CLIENT" block in
# /etc/boot/startup.sh) creates window 3 too and switches the cockpit between
# 3 and 33 by itself. Every car that showed "loading" or lost the phone's map
# ran it (#105, #24, #25): the display manager listed window 3 twice. Its
# program is renamed, so the startup block finds nothing and starts nothing,
# and stopped; the uninstall puts it back. startup.sh is not touched.
RENDER_OLD="$APP_MOUNT/navigation/opengl-render-qnx"
RENDER_OFF="$RENDER_OLD.clustermap-off"
if [ -f "$RENDER_OLD" ]; then
    if mv "$RENDER_OLD" "$RENDER_OFF" 2>/dev/null; then
        slay -f opengl-render-qnx >/dev/null 2>&1 || :
        echo "Older cluster renderer (VcMOSTRenderMqb, /navigation/opengl-render-qnx): switched off, it takes the same cockpit window. The uninstall puts it back."
    else
        echo "WARNING: an older cluster renderer (/navigation/opengl-render-qnx) is installed and could not be switched off. It takes the same cockpit window: the map may show \"loading\" or go back to the car's map. Remove it (its startup.sh block) and install again." >&2
    fi
elif pidin ar 2>/dev/null | grep opengl-render-qnx >/dev/null 2>&1; then
    echo "WARNING: an older cluster renderer (opengl-render-qnx) is running from somewhere else. It takes the same cockpit window: the map may show \"loading\" or go back to the car's map. Remove it and reboot." >&2
fi

# A gal_dualscreen.conf in the root of a card is read by the hook before the
# installed one (for quick tests), so an old copy left there overrides this
# install whenever that card is in (#24: wrong map size only with the card in).
for ROOT_CONF in /fs/sda0/gal_dualscreen.conf /fs/sdb0/gal_dualscreen.conf; do
    if [ -f "$ROOT_CONF" ]; then
        echo "WARNING: $ROOT_CONF is read instead of the installed settings while that card is in. Delete it unless you put it there on purpose." >&2
    fi
done

# Install stream-player to /mnt/app/navigation
# Through a new file and a rename: copying over the old player fails while it
# runs, and would leave the old one in place.
if [ -x "$CARD_ROOT/stream-player" ]; then
    PLAYER_DST="$APP_MOUNT/navigation/stream-player"
    if cp "$CARD_ROOT/stream-player" "$PLAYER_DST.new" 2>/dev/null && \
       [ "`wc -c < $CARD_ROOT/stream-player`" = "`wc -c < $PLAYER_DST.new`" ] && \
       chmod 755 "$PLAYER_DST.new" && mv "$PLAYER_DST.new" "$PLAYER_DST"; then
        echo "Installed stream-player to: $PLAYER_DST"
    else
        rm -f "$PLAYER_DST.new"
        echo "WARNING: could not install stream-player to $PLAYER_DST; the previous player, if any, stays." >&2
    fi
fi

# The CarPlay map, when this unit's CarPlay library is the one the hook knows.
CARPLAY_WHY=
if [ "$CARPLAY" -eq 0 ]; then
    CARPLAY_WHY="turned off (--no-carplay or CLUSTERMAP_CARPLAY=0)"
elif [ ! -r "$CARD_ROOT/carplay/libcarplay_cluster.so" ] || [ ! -r "$CARD_ROOT/carplay/carplay_cluster.sh" ]; then
    CARPLAY_WHY="its files are not in this package"
elif [ "$AIRPLAY_ALLOWED" -ne 1 ]; then
    if [ -z "$AIRPLAY_NOW" ]; then
        CARPLAY_WHY="this unit has no $AIRPLAY_LIB"
    elif [ -n "$AIRPLAY_TRIAL" ]; then
        CARPLAY_WHY="this unit's CarPlay library is a different build ($AIRPLAY_NOW bytes), and CLUSTERMAP_CARPLAY_TRIAL says $AIRPLAY_TRIAL"
    else
        CARPLAY_WHY="this unit's CarPlay library is a different build ($AIRPLAY_NOW bytes), which needs a port"
    fi
elif [ -d "$APP_MOUNT/carplaymaps" ] || grep -q carplaymaps "$APP_MOUNT/eso/bin/apps/dio_manager" 2>/dev/null; then
    CARPLAY_WHY="CarPlay Maps VC is installed; uninstall it first to use this one"
else
    cp "$CARD_ROOT/carplay/libcarplay_cluster.so" "$PRELOAD_WRITE_DIR/libcarplay_cluster.so.new" && \
        cp "$CARD_ROOT/carplay/carplay_cluster.sh" "$PRELOAD_WRITE_DIR/carplay_cluster.sh" && \
        [ "`wc -c < $CARD_ROOT/carplay/libcarplay_cluster.so`" = "`wc -c < $PRELOAD_WRITE_DIR/libcarplay_cluster.so.new`" ] && \
        chmod 755 "$PRELOAD_WRITE_DIR/libcarplay_cluster.so.new" "$PRELOAD_WRITE_DIR/carplay_cluster.sh" && \
        mv "$PRELOAD_WRITE_DIR/libcarplay_cluster.so.new" "$PRELOAD_WRITE_DIR/libcarplay_cluster.so" && CARPLAY_OK=1
    if [ "$CARPLAY_OK" -eq 1 ]; then
        echo "Installed the CarPlay map files to: $PRELOAD_WRITE_DIR"
        if [ "$AIRPLAY_BY_TRAIN" -eq 1 ]; then
            echo "CarPlay map: this unit's CarPlay library ($AIRPLAY_NOW bytes) is car-tested on $TRAIN."
        elif [ "$AIRPLAY_NOW" != "$AIRPLAY_SIZE" ] && [ "$AIRPLAY_NOW" != "$AIRPLAY_SIZE_2" ]; then
            echo "CarPlay map: UNTESTED CarPlay library ($AIRPLAY_NOW bytes), allowed by"
            echo "             CLUSTERMAP_CARPLAY_TRIAL. The hook checks the names and first"
            echo "             bytes of the functions it attaches to. That does not prove this"
            echo "             build fits: if CarPlay misbehaves, remove the line and install"
            echo "             again."
        fi
    else
        rm -f "$PRELOAD_WRITE_DIR/libcarplay_cluster.so.new"
        CARPLAY_WHY="copying its files failed"
    fi
fi
[ "$CARPLAY_OK" -eq 1 ] || echo "CarPlay map: not installed, $CARPLAY_WHY."

# CLUSTERMAP_CARPLAY_SCALE=<percent>, 70 to 200: declare the display that
# much larger in millimetres than the 200 mm wide the hook declares by
# default. The iPhone picks its UI scale from pixels per millimetre, so a
# larger display at the same pixels gets a smaller UI and more map; below
# 100 the UI is larger. The frame stays the window's size, so it costs no
# decoding time (#19; ipaifix/mst2-carplay-scale and DiPlay found the same
# on the main screen).
#
# CLUSTERMAP_CARPLAY_FRAME_SCALE=<percent>, 100 to 200: the beta13 way, asked
# for by testers who preferred it (#10). The iPhone is asked for a frame that
# much larger, at the same pixel density, and the player shrinks it into the
# window. More map, smaller everything, at a cost in decoding time: the
# player decodes in software (#19). It replaces CLUSTERMAP_CARPLAY_SCALE.
CP_SCALE=`sed -n 's/^CLUSTERMAP_CARPLAY_SCALE=\([0-9]*\)[ 	]*$/\1/p' \
    "$PRELOAD_WRITE_DIR/gal_dualscreen.conf" 2>/dev/null | tail -1`
case "$CP_SCALE" in
    '') CP_SCALE=100 ;;
esac
[ "$CP_SCALE" -lt 70 ] && CP_SCALE=70
[ "$CP_SCALE" -gt 200 ] && CP_SCALE=200
CP_FRAME=`sed -n 's/^CLUSTERMAP_CARPLAY_FRAME_SCALE=\([0-9]*\)[ 	]*$/\1/p' \
    "$PRELOAD_WRITE_DIR/gal_dualscreen.conf" 2>/dev/null | tail -1`
case "$CP_FRAME" in
    '') CP_FRAME=100 ;;
esac
[ "$CP_FRAME" -gt 200 ] && CP_FRAME=200
CP_W=$MAP_W; CP_H=$MAP_H
# Even sizes: H.264 frames are encoded in 2x2 chroma blocks.
if [ "$CP_FRAME" -gt 100 ]; then
    CP_SCALE=$CP_FRAME
    CP_W=`expr $MAP_W \* $CP_FRAME / 200 \* 2`
    CP_H=`expr $MAP_H \* $CP_FRAME / 200 \* 2`
fi
# CLUSTERMAP_CARPLAY_ZOOM=<percent>, 50 to 200: the cockpit display's
# zoomFactor, as RandomGenerated543's SEAT port sends it (70 there). Unset:
# not sent, as before.
CP_ZOOM=`sed -n 's/^CLUSTERMAP_CARPLAY_ZOOM=\([0-9]*\)[ 	]*$/\1/p' \
    "$PRELOAD_WRITE_DIR/gal_dualscreen.conf" 2>/dev/null | tail -1`
# if, not "[ ] &&": a false test ending a case arm stops the install under
# set -e on the unit (beta14 #52; cpzoom1 failed this way, #19).
if [ -n "$CP_ZOOM" ]; then
    if [ "$CP_ZOOM" -lt 50 ] || [ "$CP_ZOOM" -gt 200 ]; then CP_ZOOM=; fi
fi
CP_W_MM=`expr 200 \* $CP_SCALE / 100`
CP_H_MM=`expr $CP_W_MM \* $CP_H / $CP_W`
if [ "$CARPLAY_OK" -eq 1 ] && [ "$CP_FRAME" -gt 100 ]; then
    echo "CarPlay map: frame ${CP_W}x${CP_H} (${CP_FRAME} %), shown in the ${MAP_W}x${MAP_H} window"
elif [ "$CARPLAY_OK" -eq 1 ] && [ "$CP_SCALE" -ne 100 ]; then
    echo "CarPlay map: display declared as ${CP_W_MM}x${CP_H_MM} mm (${CP_SCALE} %) for the ${MAP_W}x${MAP_H} window"
fi

# CarPlay's safe area: the part of the window the dials do not cover, where
# the iPhone keeps the car and its instruction card. The same
# GAL_SECONDARY_INSETS (top,bottom,left,right) Android Auto uses, which are
# in its 800x480 frame, less the margins, scaled to the window. harman-f's hook
# reads it when the iPhone connects. Without it the whole window counts as
# visible (Golf R: card and car under the dials).
CARPLAY_SAFEAREA=$APP_MOUNT/root/mibr-carplay111-safearea.conf
if [ "$CARPLAY_OK" -eq 1 ]; then
    # CLUSTERMAP_CARPLAY_INSETS (same four numbers) moves only CarPlay's
    # safe area, so Android Auto keeps GAL_SECONDARY_INSETS (#19: the ETA
    # line under the SEAT dials).
    INSETS=`sed -n 's/^CLUSTERMAP_CARPLAY_INSETS=\([0-9]*\),\([0-9]*\),\([0-9]*\),\([0-9]*\)[ 	]*$/\1 \2 \3 \4/p' \
        "$PRELOAD_WRITE_DIR/gal_dualscreen.conf" 2>/dev/null | tail -1`
    if [ -n "$INSETS" ]; then
        echo "CarPlay map: insets from CLUSTERMAP_CARPLAY_INSETS"
    else
        INSETS=`sed -n 's/^GAL_SECONDARY_INSETS=\([0-9]*\),\([0-9]*\),\([0-9]*\),\([0-9]*\)[ 	]*$/\1 \2 \3 \4/p' \
            "$PRELOAD_WRITE_DIR/gal_dualscreen.conf" 2>/dev/null | tail -1`
    fi
    set -- ${INSETS:-40 40 127 127}
    # The insets count from the edge of the whole 800x480 frame, margins of
    # the band included; CarPlay has no margins, so take them off first (SEAT
    # and Skoda: 91 px top and bottom, which had made the safe area too
    # small). BAND_MARGIN, not MARGIN: with CLUSTERMAP_FULL_FRAME the Android
    # Auto margins are 0, but the insets are still set for the band, and
    # CarPlay knows nothing of full frame.
    IN_T=`expr $1 - $BAND_MARGIN_H / 2 || :`; [ "$IN_T" -lt 0 ] && IN_T=0
    IN_B=`expr $2 - $BAND_MARGIN_H / 2 || :`; [ "$IN_B" -lt 0 ] && IN_B=0
    IN_L=`expr $3 - $BAND_MARGIN_W / 2 || :`; [ "$IN_L" -lt 0 ] && IN_L=0
    IN_R=`expr $4 - $BAND_MARGIN_W / 2 || :`; [ "$IN_R" -lt 0 ] && IN_R=0
    SAFE_Y=`expr $IN_T \* $CP_H / \( 480 - $BAND_MARGIN_H \) || :`
    SAFE_B=`expr $IN_B \* $CP_H / \( 480 - $BAND_MARGIN_H \) || :`
    SAFE_X=`expr $IN_L \* $CP_W / \( 800 - $BAND_MARGIN_W \) || :`
    SAFE_R=`expr $IN_R \* $CP_W / \( 800 - $BAND_MARGIN_W \) || :`
    SAFE_W=`expr $CP_W - $SAFE_X - $SAFE_R || :`
    SAFE_H=`expr $CP_H - $SAFE_Y - $SAFE_B || :`
    # echo, not printf: some units have no printf binary
    if [ "$SAFE_W" -ge 160 ] && [ "$SAFE_H" -ge 120 ] &&
       { echo "x=$SAFE_X"; echo "y=$SAFE_Y"; echo "w=$SAFE_W"; echo "h=$SAFE_H"; } > "$CARPLAY_SAFEAREA"; then
        echo "CarPlay map: safe area ${SAFE_W}x${SAFE_H} at ${SAFE_X},${SAFE_Y} (from the insets)"
    else
        rm -f "$CARPLAY_SAFEAREA"
        echo "CarPlay map: insets leave too little of the window; using all of it"
    fi
else
    rm -f "$CARPLAY_SAFEAREA" 2>/dev/null || true
fi

# What the iPhone draws on the cluster, from gal_dualscreen.conf. harman-f's
# hook reads these files when the iPhone connects; with none of the settings
# present they are removed and the iPhone draws its default.
#   CLUSTERMAP_CARPLAY_VIEW=full|map|card   map and card, the map only, or the card only
#   CLUSTERMAP_CARPLAY_SPEEDLIMIT, _COMPASS, _ETA = yes|no
#   CLUSTERMAP_CARPLAY_CARD_POSITION=left|right|top
CP_NAV=$APP_MOUNT/root/mibr-carplay111-nav
cp_setting() {
    sed -n "s/^CLUSTERMAP_CARPLAY_$1=\\([a-z]*\\)[ 	]*\$/\\1/p" \
        "$PRELOAD_WRITE_DIR/gal_dualscreen.conf" 2>/dev/null | tail -1
}
rm -f "$CP_NAV-query.enabled" "$CP_NAV.surface" "$CP_NAV.showSpeedLimit" \
      "$CP_NAV.showCompass" "$CP_NAV.showETA" "$CP_NAV.maneuverLayout" 2>/dev/null || true
if [ "$CARPLAY_OK" -eq 1 ]; then
    CP_VIEW=`cp_setting VIEW`
    case "$CP_VIEW" in
        map)  echo map > "$CP_NAV.surface" ;;
        card) echo instructioncard > "$CP_NAV.surface" ;;
        full) echo base > "$CP_NAV.surface" ;;
        '')   ;;
        *)    echo "CarPlay map: CLUSTERMAP_CARPLAY_VIEW=$CP_VIEW not understood (full, map or card); ignored" ;;
    esac
    CP_QUERY=
    for k in SPEEDLIMIT:showSpeedLimit COMPASS:showCompass ETA:showETA; do
        v=`cp_setting ${k%%:*}`
        case "$v" in
            yes|no) echo "$v" > "$CP_NAV.${k#*:}"; CP_QUERY="$CP_QUERY ${k#*:}=$v" ;;
            '') ;;
            *) echo "CarPlay map: CLUSTERMAP_CARPLAY_${k%%:*}=$v not understood (yes or no); ignored" ;;
        esac
    done
    v=`cp_setting CARD_POSITION`
    # Unset on SEAT: top. With a route the iPhone otherwise puts the card on
    # the left and the car under the right dial; owners found top keeps the
    # car centred (#19). "iphone" leaves it to the iPhone, as before.
    if [ -z "$v" ] && [ "$CAR_MAKE" = SEAT ]; then
        v=top
        echo "CarPlay map: card at the top by default on SEAT (CLUSTERMAP_CARPLAY_CARD_POSITION=iphone to leave it to the iPhone)"
    fi
    case "$v" in
        left|right|top) echo "$v" > "$CP_NAV.maneuverLayout"; CP_QUERY="$CP_QUERY card=$v" ;;
        ''|iphone) ;;
        *) echo "CarPlay map: CLUSTERMAP_CARPLAY_CARD_POSITION=$v not understood (left, right, top or iphone); ignored" ;;
    esac
    # if, not "[ ] &&": as the last command of this block a false test would
    # end the install under set -e (beta14, #52).
    if [ -n "$CP_QUERY" ]; then
        : > "$CP_NAV-query.enabled"
    fi
    if [ -n "$CP_VIEW$CP_QUERY" ]; then
        echo "CarPlay map: view ${CP_VIEW:-full};${CP_QUERY:- iPhone defaults}"
    fi
fi

mount -ur "$APP_MOUNT" 2>/dev/null || true
APP_WRITABLE=0
echo "Installed preload target: $PRELOAD_SO_ALIAS"

TARGET_IS_HOOKED=0
if grep -q 'libgal_hook.so' "$TARGET_CONFIG" 2>/dev/null; then
    TARGET_IS_HOOKED=1
fi

# The untouched supervisor config. The unit's own copy (beside the target) is
# the truth; the card's copy is refreshed from the unit at every install,
# because a card can have been in another car, or the unit's firmware can
# have been updated since the card's copy was made. Rebuilding a repeat
# install from a stale card copy would write another unit's config here.
# Never label an already-injected file as the original.
PERSISTENT_OK=0
if [ -r "$PERSISTENT_BACKUP" ] && ! grep -q 'libgal_hook.so' "$PERSISTENT_BACKUP" 2>/dev/null &&
   ! grep -q 'libcarplay_cluster.so' "$PERSISTENT_BACKUP" 2>/dev/null; then
    PERSISTENT_OK=1
fi
if [ "$TARGET_IS_HOOKED" -eq 0 ] && ! grep -q 'libcarplay_cluster.so' "$TARGET_CONFIG" 2>/dev/null; then
    cp "$TARGET_CONFIG" "$ORIGINAL" || exit 1
    echo "Saved untouched supervisor config: $ORIGINAL"
elif [ "$PERSISTENT_OK" -eq 1 ]; then
    cp "$PERSISTENT_BACKUP" "$ORIGINAL" || exit 1
    echo "Saved untouched supervisor config (from the unit's own copy): $ORIGINAL"
elif [ -r "$ORIGINAL" ]; then
    echo "NOTE: the unit has no untouched copy of its supervisor config; using the card's: $ORIGINAL"
else
    echo "Active config is already injected and no untouched backup is available" >&2
    echo "Refusing to overwrite or mislabel the original firmware config" >&2
    exit 1
fi

if grep -q 'libgal_hook.so' "$ORIGINAL" 2>/dev/null; then
    echo "SD recovery copy is not untouched: $ORIGINAL" >&2
    exit 1
fi
LD_LIBRARY_PATH="$VALIDATOR_LD_LIBRARY_PATH" "$JSONLINT" --file "$ORIGINAL" || {
    echo "SD recovery copy failed jsonlint: $ORIGINAL" >&2
    exit 1
}

# A repeated install is rebuilt from the first untouched backup. This avoids
# accumulating duplicate LD_PRELOAD/environment entries.
# ORIGINAL was just refreshed from the unit (above), so it is this unit's.
SOURCE="$ORIGINAL"

TEMP="$CARD_ROOT/logs/smartphone_integrator.json.new.$$"

# Point the hook at the SD-card log path. The SD card is writable right
# now (this script required it), and stays writable across a GAL restart
# that does not go through a fresh boot. It mounts read-only again on the
# next boot unless something remounts it before GAL starts -- which is
# before any interactive login shell could run a .profile-based
# "mount -uw" workaround. libgal_hook.so's own hook_vlog() already
# handles that case: if opening this path fails, it falls back to
# /tmp/gal_dualscreen.log automatically. hook_status.sh and
# runtime_debug.sh both check the SD path first and fall back to /tmp the
# same way, so no separate configuration is needed here for that case.
[ -n "$LOG_PATH_REQUESTED" ] || HOOK_LOG_PATH="$LOG_DIR/gal_dualscreen.log"
# Only emit the variable when asked, so the default install is
# byte-identical to before this option existed.
#
# Emit ONLY variables that differ from their built-in defaults.
#
# smartphone_integrator silently drops entries past a limit in this
# array: with 11 entries the whole injection vanished -- GAL started with
# no LD_PRELOAD and no GAL_DUALSCREEN_* at all, keeping only the last two
# (the stock LD_LIBRARY_PATH and IPL_CONFIG_DIR_GAL), while the config on
# disk still looked correct. Nothing reports this; the hook simply never
# loads. Nine entries were fine, so keep this list as short as possible
# and never assume a new variable is free.
OPT_ENV=
# GAL_STREAM_ENABLE and GAL_DUALSCREEN_CLUSTER_INPUT both default ON inside
# the hook (environment_flag_default_on), so the OFF value is the one that has
# to be emitted -- the reverse of what these two lines used to do. Emitting the
# ON value spent a slot saying what the hook already assumed, and, far worse,
# --no-stream and --no-cluster-input emitted NOTHING and so did nothing at all:
# the hook fell back to its default and turned the feature on anyway, while the
# summary below dutifully reported it as 0.
[ "$STREAM" -eq 0 ] && OPT_ENV="$OPT_ENV\"GAL_STREAM_ENABLE=0\", "
[ -n "$AAP_MINOR" ] && OPT_ENV="$OPT_ENV\"GAL_DUALSCREEN_AAP_MINOR=$AAP_MINOR\", "
[ "$CLUSTER_INPUT" -eq 0 ] && OPT_ENV="$OPT_ENV\"GAL_DUALSCREEN_CLUSTER_INPUT=0\", "
[ "$SECOND_SINK" -eq 0 ] && OPT_ENV="$OPT_ENV\"GAL_DUALSCREEN_SECOND_SINK=0\", "
[ "$INJECT_META" -eq 0 ] && OPT_ENV="$OPT_ENV\"GAL_DUALSCREEN_INJECT_META=0\", "
# --output is the only knob on this axis now; --no-secondary-render folds
# into it at parse time above.
[ -n "$OUTPUT" ] && [ "$OUTPUT" != gal ] && \
    OPT_ENV="$OPT_ENV\"GAL_DUALSCREEN_OUTPUT=$OUTPUT\", "
# 3 is the hook's built-in default displayable; only send a different one.
[ -n "$DISPLAYABLE" ] && [ "$DISPLAYABLE" -ne 3 ] && \
    OPT_ENV="$OPT_ENV\"GAL_VC_DISPLAYABLE_ID=$DISPLAYABLE\", "
# 140 is the hook's built-in default, so emitting it wastes one of the few
# env slots available. Only send it when it differs -- and the two MUST
# agree: if this said 160 while the hook defaulted to 140, running without
# --dpi would emit nothing and silently apply 140 while every message here
# claimed 160. tools/verify_constants.sh checks they match.
DPI_ENV=
[ "$DPI" -ne 140 ] && DPI_ENV="\"GAL_SECONDARY_DPI=$DPI\", "
# GAL_HOOK_LOG costs one of the ~10 usable slots, and without it the hook
# uses its own compiled-in path and still falls back to /tmp when the card
# is read-only -- which it is on every boot. The status scripts search the
# built-in path too, so omitting it changes where the log lands but not
# whether the tooling finds it. Emitted only when --log asked for a path.
LOG_ENV=
[ -n "$LOG_PATH_REQUESTED" ] && LOG_ENV="\"GAL_HOOK_LOG=$HOOK_LOG_PATH\", "
# The master switch is the card's: the hook takes a key from its settings file
# only when the environment has none, so a fixed 1 here made
# GAL_DUALSCREEN_ENABLE=0 in gal_dualscreen.conf do nothing (#101).
HOOK_ENABLE=1
if [ "`sed -n 's/^GAL_DUALSCREEN_ENABLE=\([01]\)[ 	]*$/\1/p' "$PRELOAD_WRITE_DIR/gal_dualscreen.conf" 2>/dev/null | tail -1`" = 0 ]; then
    HOOK_ENABLE=0
    echo "GAL_DUALSCREEN_ENABLE=0: the hook is installed but switched off. Android Auto"
    echo "  runs as stock, with no map on the cockpit, until it is 1 again."
fi
INJECTION="\"LD_PRELOAD=$PRELOAD_SO_ALIAS\", \"GAL_DUALSCREEN_ENABLE=$HOOK_ENABLE\", \"GAL_DUALSCREEN_DEBUG=$DEBUG\", $OPT_ENV$LOG_ENV$DPI_ENV"

# Refuse to write an array that smartphone_integrator would silently
# truncate. At 11 entries the ENTIRE injection was dropped once -- GAL ran
# with no LD_PRELOAD at all while this file still looked correct on disk,
# and the only symptom was a hook that never loaded. Failing loudly here is
# worth more than one extra option.
INJECTED_COUNT=`echo "$INJECTION" | awk -F'", ' '{print NF-1}'`
EXISTING_COUNT=`awk '
BEGIN { in_children=0; in_gal=0; in_envs=0; line="" }
{
    if ($0 ~ /"children"[ 	]*:/) in_children=1
    if (in_children && !in_gal && $0 ~ /^[ 	]*"gal"[ 	]*:/) in_gal=1
    # The array is on one line on the Golf, one entry per line on VWG11:
    # gather it up to the closing bracket either way.
    if (in_gal && !in_envs && $0 ~ /^[ 	]*"envs"[ 	]*:\[/) {
        in_envs=1; line=$0; sub(/^[^\[]*\[/, "", line)
    } else if (in_envs) line=line $0
    if (in_envs && line ~ /\]/) {
        sub(/\].*$/, "", line)
        n=split(line, parts, /"[ 	]*,[ 	]*"/)
        if (line ~ /^[ 	]*$/) n=0
        print n; exit
    }
}' "$SOURCE"`
[ -n "$EXISTING_COUNT" ] || EXISTING_COUNT=0
ENTRY_COUNT=`expr $INJECTED_COUNT + $EXISTING_COUNT`
echo "Environment entries: $INJECTED_COUNT injected + $EXISTING_COUNT already in the stock config"
if [ "$ENTRY_COUNT" -gt 10 ]; then
    echo "Refusing to install: $ENTRY_COUNT environment entries." >&2
    echo "smartphone_integrator silently drops the whole array past ~10," >&2
    echo "so the hook would never load and nothing would report it." >&2
    echo "Drop an option -- the default for --dpi costs nothing." >&2
    exit 3
fi
echo "Environment entries: $ENTRY_COUNT (limit 10)"

awk -v injection="$INJECTION" '
BEGIN { in_children=0; in_gal=0; patched=0 }
{
    if ($0 ~ /"children"[ 	]*:/) in_children=1
    if (in_children && !in_gal && $0 ~ /^[ 	]*"gal"[ 	]*:/) in_gal=1
    if (in_gal && !patched && $0 ~ /^[ 	]*"envs"[ 	]*:\[/) {
        sub(/\[/, "[" injection)
        patched=1
    }
    print
}
END { if (!patched) exit 3 }
' "$SOURCE" > "$TEMP" || {
    rm -f "$TEMP"
    echo "Could not locate children.gal.envs in $SOURCE" >&2
    exit 1
}

grep -q "LD_PRELOAD=$PRELOAD_SO_ALIAS" "$TEMP" || {
    rm -f "$TEMP"
    echo "Generated supervisor config failed verification" >&2
    exit 1
}

# CarPlay: the same edit, on the "carplay" child (dio_manager). Built into the
# same file because a repeated install starts again from the untouched
# original, and the uninstall puts that original back: both phones' entries
# always come and go together. CarPlay is asked for the cluster map
# window's size, read above, so its stream fills the player's window.
if [ "$CARPLAY_OK" -eq 1 ]; then
    CP_INJECTION="\"LD_PRELOAD=$CARPLAY_PRELOAD\", \"ALTSCREEN111_WIDTH=$CP_W\", \"ALTSCREEN111_HEIGHT=$CP_H\", "
    CP_ADDED=3
    if [ "$CP_SCALE" -ne 100 ]; then
        CP_INJECTION="$CP_INJECTION\"ALTSCREEN111_WIDTH_MM=$CP_W_MM\", \"ALTSCREEN111_HEIGHT_MM=$CP_H_MM\", "
        CP_ADDED=`expr $CP_ADDED + 2`
    fi
    if [ -n "$CP_ZOOM" ]; then
        CP_INJECTION="$CP_INJECTION\"ALTSCREEN111_ZOOM_FACTOR=$CP_ZOOM\", "
        CP_ADDED=`expr $CP_ADDED + 1`
    fi
    CP_EXISTING=`awk '
    BEGIN { in_children=0; in_cp=0; in_envs=0; line="" }
    {
        if ($0 ~ /"children"[ 	]*:/) in_children=1
        if (in_children && !in_cp && $0 ~ /^[ 	]*"carplay"[ 	]*:/) in_cp=1
        # One line on the Golf, one entry per line on VWG11 and Audi AUG22:
        # gathered up to the closing bracket, as for gal above. Reading only
        # the first line counted 0 there and missed another mod LD_PRELOAD.
        if (in_cp && !in_envs && $0 ~ /^[ 	]*"envs"[ 	]*:\[/) {
            in_envs=1; line=$0; sub(/^[^\[]*\[/, "", line)
        } else if (in_envs) line=line $0
        if (in_envs && line ~ /\]/) {
            sub(/\].*$/, "", line)
            if (line ~ /LD_PRELOAD/) { print "preload"; exit }
            n=split(line, parts, /"[ 	]*,[ 	]*"/)
            if (line ~ /^[ 	]*$/) n=0
            print n; exit
        }
    }' "$SOURCE"`
    if [ "$CP_EXISTING" = preload ]; then
        CARPLAY_OK=0; CARPLAY_WHY="CarPlay already has a preloaded library (another CarPlay mod?)"
    elif [ -z "$CP_EXISTING" ]; then
        CARPLAY_OK=0; CARPLAY_WHY="no carplay entry in the supervisor config"
    elif [ `expr $CP_EXISTING + $CP_ADDED` -gt 10 ]; then
        CARPLAY_OK=0; CARPLAY_WHY="its environment list would pass the limit of 10"
    else
        awk -v injection="$CP_INJECTION" '
        BEGIN { in_children=0; in_cp=0; patched=0 }
        {
            if ($0 ~ /"children"[ 	]*:/) in_children=1
            if (in_children && !in_cp && $0 ~ /^[ 	]*"carplay"[ 	]*:/) in_cp=1
            if (in_cp && !patched && $0 ~ /^[ 	]*"envs"[ 	]*:\[/) {
                sub(/\[/, "[" injection)
                patched=1
            }
            print
        }
        END { if (!patched) exit 3 }
        ' "$TEMP" > "$TEMP.cp" && grep -q "LD_PRELOAD=$CARPLAY_PRELOAD" "$TEMP.cp" && \
            grep -q "LD_PRELOAD=$PRELOAD_SO_ALIAS" "$TEMP.cp" && mv "$TEMP.cp" "$TEMP" || {
            rm -f "$TEMP.cp"
            CARPLAY_OK=0; CARPLAY_WHY="the carplay entry could not be edited"
        }
    fi
    if [ "$CARPLAY_OK" -eq 1 ]; then
        echo "CarPlay map: added to dio_manager's start-up ($CP_EXISTING + $CP_ADDED environment entries)."
    else
        echo "CarPlay map: not installed, $CARPLAY_WHY. The Android Auto map is unaffected."
    fi
fi
LD_LIBRARY_PATH="$VALIDATOR_LD_LIBRARY_PATH" "$JSONLINT" --file "$TEMP" || {
    rm -f "$TEMP"
    echo "Generated supervisor config failed jsonlint validation" >&2
    exit 1
}

mount -uw "$SYSTEM_MOUNT" 2>/dev/null || {
    rm -f "$TEMP"
    echo "Cannot remount $SYSTEM_MOUNT read-write" >&2
    exit 1
}
SYSTEM_WRITABLE=1
cp "$TARGET_CONFIG" "$BACKUP_DIR/smartphone_integrator.json.before_enable.$$"
# ORIGINAL is the unit's untouched config as of this install (see above):
# written again each time, so a firmware update or another unit's stale copy
# never survives here. Uninstall restores from this file.
if [ "$PERSISTENT_OK" -eq 0 ] || [ "$TARGET_IS_HOOKED" -eq 0 ]; then
    cp "$ORIGINAL" "$PERSISTENT_BACKUP" || {
        echo "Could not create persistent recovery copy: $PERSISTENT_BACKUP" >&2
        exit 1
    }
fi
if grep -q 'libgal_hook.so' "$PERSISTENT_BACKUP" 2>/dev/null; then
    echo "Persistent recovery copy unexpectedly contains the hook: $PERSISTENT_BACKUP" >&2
    exit 1
fi
LD_LIBRARY_PATH="$VALIDATOR_LD_LIBRARY_PATH" "$JSONLINT" --file "$PERSISTENT_BACKUP" || {
    echo "Persistent recovery copy failed jsonlint: $PERSISTENT_BACKUP" >&2
    exit 1
}
SYSTEM_TEMP="$TARGET_CONFIG.gal-dualscreen-new"
cp "$TEMP" "$SYSTEM_TEMP" || {
    rm -f "$TEMP"
    echo "Could not stage $SYSTEM_TEMP" >&2
    exit 1
}
chmod 644 "$SYSTEM_TEMP" 2>/dev/null || true
grep -q "LD_PRELOAD=$PRELOAD_SO_ALIAS" "$SYSTEM_TEMP" || {
    rm -f "$TEMP"
    echo "Staged supervisor config failed verification" >&2
    exit 1
}
LD_LIBRARY_PATH="$VALIDATOR_LD_LIBRARY_PATH" "$JSONLINT" --file "$SYSTEM_TEMP" || {
    rm -f "$TEMP"
    echo "Staged supervisor config failed jsonlint validation" >&2
    exit 1
}
mv "$SYSTEM_TEMP" "$TARGET_CONFIG" || {
    rm -f "$TEMP"
    echo "Could not atomically install $TARGET_CONFIG" >&2
    exit 1
}
SYSTEM_TEMP=
LD_LIBRARY_PATH="$VALIDATOR_LD_LIBRARY_PATH" "$JSONLINT" --file "$TARGET_CONFIG" || {
    echo "Installed config failed validation; restoring persistent original" >&2
    if cp "$PERSISTENT_BACKUP" "$TARGET_CONFIG"; then
        echo "Restored $TARGET_CONFIG from $PERSISTENT_BACKUP" >&2
    else
        echo "CRITICAL: restore from $PERSISTENT_BACKUP also failed" >&2
        echo "CRITICAL: $TARGET_CONFIG is left in a state that failed jsonlint" >&2
        echo "CRITICAL: fix this file manually before rebooting the unit" >&2
    fi
    rm -f "$TEMP"
    exit 1
}
rm -f "$TEMP"
if [ "$CARPLAY_OK" -eq 1 ]; then carplay_pf_open; else carplay_pf_close; fi
sync
mount -ur "$SYSTEM_MOUNT" 2>/dev/null || true
SYSTEM_WRITABLE=0
trap - 0 1 2 15

echo "Hook environment installed for the supervisor-owned GAL."
echo "  persistent config: $TARGET_CONFIG"
echo "  persistent recovery: $PERSISTENT_BACKUP"
echo "  preload target: $PRELOAD_SO_ALIAS"
echo "    on the internal /mnt/app partition, not the SD card -- avoids the"
echo "    SD-card mount-timing race at GAL's boot-time launch."
echo "  output mode: $OUTPUT (video forwarded to stream-player)"
if [ "$FRAME_MODE" = 1080p ] || [ "$FRAME_MODE" = 720p ]; then
    echo "  cluster: Android Auto ${FRAME_W}x${FRAME_H} @ 30 fps (margins ${MARGIN_W}x${MARGIN_H}, 1:1 test), DPI $EFFECTIVE_DPI, ${MAP_W}x${MAP_H} window"
elif [ "$FULL_FRAME" = 1 ]; then
    echo "  cluster: Android Auto ${FRAME_W}x${FRAME_H} @ 30 fps (full frame, pixel aspect ${PIXEL_ASPECT_E4}/10000), DPI $EFFECTIVE_DPI, ${MAP_W}x${MAP_H} window"
else
    echo "  cluster: Android Auto ${FRAME_W}x${FRAME_H} @ 30 fps (margins ${MARGIN_W}x${MARGIN_H}), DPI $EFFECTIVE_DPI, ${MAP_W}x${MAP_H} window"
fi
if [ "$CARPLAY_OK" -eq 1 ]; then echo "  CarPlay map: installed, ${MAP_W}x${MAP_H}"; else echo "  CarPlay map: no ($CARPLAY_WHY)"; fi
echo "  debug logs: $DEBUG"
echo "  second sink: $SECOND_SINK   inject metadata: $INJECT_META"
# The hook reads GAL_DUALSCREEN_AAP_MINOR from its own copy of the settings at
# run time, so --aap-minor is not the only source. Without the flag this line
# used to say "2 (stock)" while the hook was in fact using the file's value --
# which sent two testers (#19, #37) chasing a protocol version they were not
# running. Report what will actually be used.
AAP_MINOR_CONF=`sed -n 's/^GAL_DUALSCREEN_AAP_MINOR=\([0-9]*\)[ 	]*$/\1/p' \
    "$PRELOAD_WRITE_DIR/gal_dualscreen.conf" 2>/dev/null | tail -1`
if [ -n "$AAP_MINOR" ]; then
    echo "  AAP minor version: $AAP_MINOR (--aap-minor)"
elif [ -n "$AAP_MINOR_CONF" ]; then
    echo "  AAP minor version: $AAP_MINOR_CONF (from gal_dualscreen.conf)"
else
    echo "  AAP minor version: 2 (stock)"
fi
echo "  stream forwarding: $STREAM"
echo "  cluster input service: $CLUSTER_INPUT"
echo "  hook log: $HOOK_LOG_PATH"
echo "    falls back to /tmp/gal_dualscreen.log (RAM-backed, does not survive"
echo "    a reboot) if the SD card is read-only when GAL starts -- true on"
echo "    every boot unless the SD card is remounted -uw before GAL starts."

# ---- Java interface: the two patches that decide whether the map stays up ----
# NavActiveIgnore must be loaded, and the turn-by-turn jar must not be. Both are
# single lines in the Java start-up script, edited through lsd_jar.sh, which
# checks every change before it replaces the file.
LSD_SH=/mnt/app/eso/hmi/lsd/lsd.sh
NAVIGNORE_MARKER=/mnt/app/eso/hmi/lsd/.aacluster_navignore_added
# Firmware where the bundled NavActiveIgnore.jar has been seen working. It is a
# Java patch: on a firmware it does not fit, the centre screen may not start,
# so it is never added automatically anywhere else.
# Where it is added without being asked is "navignore" in profiles.conf: trains
# where owners ran this same jar, or the toolbox's copy of it, and sent logs
# showing it loaded (#15). Those logs came from the green menu, which only runs
# once the centre screen has started, so the patch fits.
# CLUSTERMAP_ADD_NAVIGNORE=1 in gal_dualscreen.conf: add it on any other
# firmware too, when the owner asks. It is the same jar the toolbox applies,
# but done here it gets lsd.sh.before_* backups and is removed again by
# uninstall. Off by default: on a firmware it does not fit, the centre screen
# may not start (see docs/Install.md, Safety and recovery).
NAVIGNORE_ASKED=`sed -n 's/^CLUSTERMAP_ADD_NAVIGNORE=\([01]\)[ 	]*$/\1/p' \
    "$PRELOAD_WRITE_DIR/gal_dualscreen.conf" 2>/dev/null | tail -1`
# Never where profiles.conf says "nonavignore": with it, Android Auto stopped
# working on an S2125 (#39, FAILED_NO_GAL_DEVICE). Owners updated to
# MHI2_ER_VWG11_K3342 run it fine with Android Auto (#39, #28; the #28 freeze
# was an edited gal.json). The Audi A4/Q5 (AUG22) is no longer on that list:
# a K3344 drops the map at every route without it (#14), and a K3346 runs
# the Audi build from M.I.B., so there it is added when the owner asks.
NAVIGNORE_NEVER=0
if train_has "$PROFILES" "$TRAIN" nonavignore; then NAVIGNORE_NEVER=1; fi
# Which build: the toolbox's patches VW classes (de.vw.mib.asl.*), most of
# which the A6/A7 C7.5 interface does not have; there the Audi build M.I.B.
# installs (harman-f; thirdparty/navactiveignore-audi) goes in instead,
# under the same name on the unit.
NAVIGNORE_SRC="$CARD_ROOT/thirdparty/NavActiveIgnore.jar"
NAVIGNORE_BUILD="toolbox (VW)"
case "$TRAIN" in
    # Every Audi interface is de.audi.*: the A3 8V (AU37x) and A4/Q5 (AUG22)
    # get the Audi build too. Car-tested on the A7 only; elsewhere it is added
    # only when the owner asks (CLUSTERMAP_ADD_NAVIGNORE=1), never on a
    # "nonavignore" train.
    *_AU*) NAVIGNORE_SRC="$CARD_ROOT/thirdparty/NavActiveIgnore_Audi.jar"; NAVIGNORE_BUILD="Audi" ;;
esac
echo
if [ ! -r "$LSD_SH" ] || [ ! -r "$CARD_ROOT/lsd_jar.sh" ]; then
    echo "WARNING: cannot check the Java interface ($LSD_SH or lsd_jar.sh missing)." >&2
else
    NAV_HAVE=`file_size /mnt/app/eso/hmi/lsd/jars/NavActiveIgnore.jar`
    NAV_WANT=`file_size "$NAVIGNORE_SRC"`
    # The start-up line without the jar file behind it: Java skips a missing
    # jar without a word, so "loaded" was reported while the cockpit still
    # dropped the map at the first route (#24, a P4512_2 whose lsd/jars held
    # only the two stock jars). Put the file back before the checks below.
    if [ -z "$NAV_HAVE" ] || [ "$NAV_HAVE" = 0 ]; then
        if sh "$CARD_ROOT/lsd_jar.sh" loaded NavActiveIgnore.jar && [ "$NAVIGNORE_NEVER" -eq 0 ] &&
           [ "$KEEP_NAVIGNORE" -eq 0 ]; then
            echo "Java check: NavActiveIgnore has its start-up line, but the jar file is missing."
            if [ -r "$NAVIGNORE_SRC" ] && sh "$CARD_ROOT/lsd_jar.sh" add NavActiveIgnore.jar "$NAVIGNORE_SRC"; then
                NAV_HAVE=`file_size /mnt/app/eso/hmi/lsd/jars/NavActiveIgnore.jar`
            else
                echo "WARNING: could not copy NavActiveIgnore.jar; the cockpit will drop the map" >&2
                echo "         when the phone starts a route. Apply it from the toolbox:" >&2
                echo "         Customization > Navigation." >&2
            fi
        fi
    fi
    if sh "$CARD_ROOT/lsd_jar.sh" loaded NavActiveIgnore.jar && [ "$NAVIGNORE_NEVER" -eq 1 ] &&
       [ "$NAVIGNORE_BUILD" = Audi ] && [ -n "$NAV_WANT" ] && [ "$NAV_HAVE" = "$NAV_WANT" ]; then
        # An Audi owner's own M.I.B. install of the Audi build (a Q5 FY on
        # K3346 has it): the warning below is about the VW build.
        echo "Java check: NavActiveIgnore (Audi build) is loaded; left as it is."
    elif sh "$CARD_ROOT/lsd_jar.sh" loaded NavActiveIgnore.jar && [ "$NAVIGNORE_NEVER" -eq 1 ]; then
        echo "WARNING: NavActiveIgnore is loaded. On firmware $TRAIN it has stopped" >&2
        echo "         Android Auto (#39). If it does, remove it with the toolbox or" >&2
        echo "         this package's uninstall, or update to MHI2_ER_VWG11_K3342." >&2
    elif sh "$CARD_ROOT/lsd_jar.sh" loaded NavActiveIgnore.jar; then
        echo "Java check: NavActiveIgnore is loaded (required)."
        # A6/A7: the VW build there patches classes this interface lacks.
        case "$TRAIN" in
            *_AU*)
                if [ -n "$NAV_WANT" ] && [ "$NAV_HAVE" != "$NAV_WANT" ]; then
                    echo "WARNING: the loaded NavActiveIgnore.jar (${NAV_HAVE:-unreadable} bytes) is not the Audi" >&2
                    echo "         build this unit needs ($NAV_WANT bytes, as M.I.B. installs it)." >&2
                fi ;;
        esac
    elif sh "$CARD_ROOT/lsd_jar.sh" loaded CarPlayNavigationPatch.jar; then
        # CarPlay Maps VC ships the same nine classes under another name.
        echo "Java check: CarPlayNavigationPatch is loaded (the same patch as NavActiveIgnore)."
    elif [ "$NAVIGNORE_NEVER" -eq 1 ]; then
        echo "Java check: NavActiveIgnore is not loaded, and is never added on $TRAIN"
        if [ "$NAVIGNORE_ASKED" = 1 ]; then
            echo "            (CLUSTERMAP_ADD_NAVIGNORE=1 ignored: it broke Android Auto on this firmware, #39)."
            echo "            Owners updated to MHI2_ER_VWG11_K3342 have it working (#39, #28)."
        fi
    elif [ "$KEEP_NAVIGNORE" -eq 1 ]; then
        echo "Java check: NavActiveIgnore is NOT loaded and was left alone (--no-navignore)."
        echo "            The cluster will drop its map when the phone navigates."
    else
        NAV_OK=0
        NAV_WHY="firmware $TRAIN"
        if train_has "$PROFILES" "$TRAIN" navignore; then NAV_OK=1; fi
        if [ "$NAV_OK" -eq 0 ] && [ "$NAVIGNORE_ASKED" = 1 ]; then
            NAV_OK=1; NAV_WHY="asked for by CLUSTERMAP_ADD_NAVIGNORE=1 on $TRAIN"
        fi
        if [ "$NAV_OK" -eq 1 ]; then
            echo "Java check: NavActiveIgnore is not loaded; adding the $NAVIGNORE_BUILD build ($NAV_WHY)."
            if ! train_has "$PROFILES" "$TRAIN" navignore; then
                echo "            It changes the script that starts the centre screen, and is not"
                echo "            added by itself here: if the screen stays black after the reboot, run"
                echo "            this package's uninstall (an UNINSTALL file on the card, see"
                echo "            docs/Install.md), which takes it out again."
            fi
            if [ ! -r "$NAVIGNORE_SRC" ]; then
                echo "WARNING: the $NAVIGNORE_BUILD NavActiveIgnore build is not in this package; not added." >&2
            elif sh "$CARD_ROOT/lsd_jar.sh" add NavActiveIgnore.jar "$NAVIGNORE_SRC"; then
                if mount -uw /mnt/app 2>/dev/null; then : > "$NAVIGNORE_MARKER"; mount -ur /mnt/app 2>/dev/null || true; fi
            else
                echo "WARNING: could not add NavActiveIgnore; lsd.sh is unchanged." >&2
                echo "         Apply it from the toolbox: Customization > Navigation." >&2
            fi
        else
            echo "WARNING: NavActiveIgnore is NOT loaded, and it is not added automatically" >&2
            echo "         on firmware $TRAIN. Without it the cluster drops the map as" >&2
            echo "         soon as the phone starts a route. To have this installer add" >&2
            echo "         it, put CLUSTERMAP_ADD_NAVIGNORE=1 in gal_dualscreen.conf and" >&2
            echo "         install again; or apply it yourself:" >&2
            if [ "$NAVIGNORE_BUILD" = Audi ]; then
                echo "         M.I.B. > Navigation > NavActiveIgnore > Enable dual navigation" >&2
                echo "         (the Audi build; the MIB2 Toolbox one is for VW and does not fit)." >&2
            else
                echo "         MIB2 Toolbox > Customization > Navigation > Ignore" >&2
                echo "         navigation-active status." >&2
            fi
            echo "         It edits the script that starts the centre screen: check SSH" >&2
            echo "         works first, and keep a copy: cp $LSD_SH $LSD_SH.myback" >&2
        fi
    fi
    # VWG11 (K3342): with NavActiveIgnore loaded CarPlay no longer connects, on
    # four owners' cars (#62, #106, two on #111; dio_manager stops at start-up
    # in the one set of logs). Android Auto runs fine with it. Cause not found.
    case "$TRAIN" in
        *_VWG11_*)
            if [ "$NAVIGNORE_NEVER" -eq 0 ] && sh "$CARD_ROOT/lsd_jar.sh" loaded NavActiveIgnore.jar; then
                echo "NOTE: on $TRAIN, owners report that CarPlay no longer connects while"
                echo "      NavActiveIgnore is loaded (#62, #106, #111). Android Auto is not"
                echo "      affected. If you use an iPhone and it stops connecting, set"
                echo "      CLUSTERMAP_ADD_NAVIGNORE=0 and run this package's uninstall, then"
                echo "      install again (or remove it where you applied it: MIB2 Toolbox)."
            fi ;;
    esac
    TBT_OK=0
    if train_has "$PROFILES" "$TRAIN" arrows; then TBT_OK=1; fi
    # Loaded already and added by this package: replaced when the card has
    # another build (lsd_jar.sh add compares sizes).
    if [ "$WITH_ARROWS" -eq 1 ] && [ -f /mnt/app/eso/hmi/lsd/.aacluster_tbt_added ] &&
       sh "$CARD_ROOT/lsd_jar.sh" loaded VCAndroidAuto.jar; then
        sh "$CARD_ROOT/lsd_jar.sh" add VCAndroidAuto.jar "$CARD_ROOT/thirdparty/VCAndroidAuto.jar" ||
            echo "WARNING: could not update VCAndroidAuto.jar; the loaded copy stays." >&2
    fi
    if [ "$WITH_ARROWS" -eq 1 ] && ! sh "$CARD_ROOT/lsd_jar.sh" loaded VCAndroidAuto.jar; then
        if [ "$TBT_OK" -eq 1 ]; then
            echo "Java check: adding VCAndroidAuto.jar beside the map (CLUSTERMAP_KEEP_ARROWS=1)."
            if sh "$CARD_ROOT/lsd_jar.sh" add VCAndroidAuto.jar "$CARD_ROOT/thirdparty/VCAndroidAuto.jar"; then
                if mount -uw /mnt/app 2>/dev/null; then : > /mnt/app/eso/hmi/lsd/.aacluster_tbt_added; mount -ur /mnt/app 2>/dev/null || true; fi
            else
                echo "WARNING: could not add VCAndroidAuto.jar; lsd.sh is unchanged." >&2
            fi
        else
            echo "WARNING: CLUSTERMAP_KEEP_ARROWS=1 ignored: the arrows jar is not known to" >&2
            echo "         work on firmware $TRAIN." >&2
        fi
    fi
    if sh "$CARD_ROOT/lsd_jar.sh" loaded VCAndroidAuto.jar; then
        if [ "$KEEP_TBT" -eq 1 ]; then
            echo "Java check: VCAndroidAuto.jar is loaded and was kept with the map."
            case "$TRAIN" in
                *_VWG*) echo "            On VW, expect the cluster map to go blank when a route starts." ;;
            esac
        elif sh "$CARD_ROOT/turn_by_turn.sh" remove; then
            :
        else
            echo "WARNING: could not remove the VCAndroidAuto.jar line; lsd.sh is unchanged." >&2
            echo "         The hook is installed, but the map may fail when a route starts." >&2
        fi
    else
        echo "Java check: VCAndroidAuto.jar is not loaded (good)."
    fi
    # One extra build of the arrows jar beside the map, never together with
    # VCAndroidAuto.jar (they carry the same classes):
    #   CLUSTERMAP_TURN_INFO=1  VCAndroidAutoTurns.jar: turn data and track
    #     info, the cockpit's view (arrows or map) left to the stock logic so
    #     the map should stay up with the cockpit's arrow beside it.
    #   CLUSTERMAP_MUSIC_INFO=1 VCAndroidAutoMusic.jar: track info only, no
    #     turn data.
    # TURN_INFO wins when both are set. Each jar the installer adds gets a
    # marker, and only marked jars are ever removed.
    CONF_FILE="$PRELOAD_WRITE_DIR/gal_dualscreen.conf"
    TURNS_ASKED=`sed -n 's/^CLUSTERMAP_TURN_INFO=\([01]\)[ 	]*$/\1/p' "$CONF_FILE" 2>/dev/null | tail -1`
    MUSIC_ASKED=`sed -n 's/^CLUSTERMAP_MUSIC_INFO=\([01]\)[ 	]*$/\1/p' "$CONF_FILE" 2>/dev/null | tail -1`
    FULL_JAR=0
    if sh "$CARD_ROOT/lsd_jar.sh" loaded VCAndroidAuto.jar; then FULL_JAR=1; fi
    WANT_JAR=
    WANT_KEY=
    WANT_WHAT=
    if [ "$TURNS_ASKED" = 1 ]; then
        WANT_JAR=VCAndroidAutoTurns.jar
        WANT_KEY=CLUSTERMAP_TURN_INFO
        WANT_WHAT="turn info and track info, cockpit view left to the cockpit"
    elif [ "$MUSIC_ASKED" = 1 ]; then
        WANT_JAR=VCAndroidAutoMusic.jar
        WANT_KEY=CLUSTERMAP_MUSIC_INFO
        WANT_WHAT="track info on the cockpit, no turn data"
    fi
    if [ "$FULL_JAR" -eq 1 ] && [ -n "$WANT_JAR" ]; then
        echo "WARNING: $WANT_KEY=1 ignored: VCAndroidAuto.jar is loaded" >&2
        echo "         (CLUSTERMAP_KEEP_ARROWS=1) and carries the same classes." >&2
        WANT_JAR=
    fi
    FOREIGN_JAR=
    for EXTRA_JAR in VCAndroidAutoMusic.jar VCAndroidAutoTurns.jar; do
        case "$EXTRA_JAR" in
            VCAndroidAutoMusic.jar) EXTRA_MARKER=/mnt/app/eso/hmi/lsd/.aacluster_music_added ;;
            *) EXTRA_MARKER=/mnt/app/eso/hmi/lsd/.aacluster_turns_added ;;
        esac
        if [ "$EXTRA_JAR" = "$WANT_JAR" ]; then
            continue
        fi
        if ! sh "$CARD_ROOT/lsd_jar.sh" loaded $EXTRA_JAR; then
            continue
        fi
        if [ -f "$EXTRA_MARKER" ]; then
            echo "Java check: removing $EXTRA_JAR (not asked for in gal_dualscreen.conf)."
            if sh "$CARD_ROOT/lsd_jar.sh" remove $EXTRA_JAR; then
                if mount -uw /mnt/app 2>/dev/null; then rm -f "$EXTRA_MARKER"; mount -ur /mnt/app 2>/dev/null || true; fi
            else
                echo "WARNING: could not remove $EXTRA_JAR; lsd.sh is unchanged." >&2
            fi
        else
            FOREIGN_JAR=$EXTRA_JAR
            echo "WARNING: $EXTRA_JAR is loaded and this installer did not add it." >&2
            echo "         Never load two of VCAndroidAuto.jar, VCAndroidAutoMusic.jar and" >&2
            echo "         VCAndroidAutoTurns.jar together: they carry the same classes." >&2
        fi
    done
    # The music and turn-info jars also go on where only they were checked.
    INFO_OK=$TBT_OK
    if train_has "$PROFILES" "$TRAIN" info; then INFO_OK=1; fi
    if [ -n "$WANT_JAR" ]; then
        case "$WANT_JAR" in
            VCAndroidAutoMusic.jar) WANT_MARKER=/mnt/app/eso/hmi/lsd/.aacluster_music_added ;;
            *) WANT_MARKER=/mnt/app/eso/hmi/lsd/.aacluster_turns_added ;;
        esac
        if [ "$INFO_OK" -ne 1 ]; then
            echo "WARNING: $WANT_KEY=1 ignored: $WANT_JAR is not known to" >&2
            echo "         work on firmware $TRAIN." >&2
        elif sh "$CARD_ROOT/lsd_jar.sh" loaded $WANT_JAR; then
            echo "Java check: $WANT_JAR is loaded ($WANT_WHAT)."
            # Loaded already: replaced when the card has another build
            # (lsd_jar.sh add compares sizes). Until v1.2.7 it never was, so
            # cars kept their first copy (#24). Only this package builds jars
            # by these two names, so no marker is needed to call it ours.
            sh "$CARD_ROOT/lsd_jar.sh" add $WANT_JAR "$CARD_ROOT/thirdparty/$WANT_JAR" ||
                echo "WARNING: could not update $WANT_JAR; the loaded copy stays." >&2
        elif [ -n "$FOREIGN_JAR" ]; then
            echo "WARNING: $WANT_KEY=1 ignored: remove $FOREIGN_JAR first." >&2
        else
            echo "Java check: adding $WANT_JAR ($WANT_KEY=1: $WANT_WHAT)."
            if sh "$CARD_ROOT/lsd_jar.sh" add $WANT_JAR "$CARD_ROOT/thirdparty/$WANT_JAR"; then
                if mount -uw /mnt/app 2>/dev/null; then : > "$WANT_MARKER"; mount -ur /mnt/app 2>/dev/null || true; fi
            else
                echo "WARNING: could not add $WANT_JAR; lsd.sh is unchanged." >&2
            fi
        fi
    fi
    # CLUSTERMAP_TURN_TEXT=auto|always|never: when the turns jar sends the
    # road name ("towards ...") to the cockpit. auto: only while the cockpit
    # is not showing the map, which already has Google's own card. The jar
    # reads it when the centre screen starts.
    TURN_TEXT_FILE=/mnt/app/root/vcaa_turn_text
    if [ "$WANT_JAR" = VCAndroidAutoTurns.jar ]; then
        TURN_TEXT=`sed -n 's/^CLUSTERMAP_TURN_TEXT=\([a-z]*\)[ 	]*$/\1/p' "$CONF_FILE" 2>/dev/null | tail -1`
        case "$TURN_TEXT" in
            auto|always|never) ;;
            "") TURN_TEXT=auto ;;
            *) echo "WARNING: CLUSTERMAP_TURN_TEXT=$TURN_TEXT is not auto, always or never; using auto." >&2
               TURN_TEXT=auto ;;
        esac
        if mount -uw /mnt/app 2>/dev/null; then
            echo "$TURN_TEXT" > "$TURN_TEXT_FILE" || echo "WARNING: could not write $TURN_TEXT_FILE" >&2
            mount -ur /mnt/app 2>/dev/null || true
        fi
        echo "Turn info: road name on the cockpit: $TURN_TEXT"
    elif [ -f "$TURN_TEXT_FILE" ]; then
        if mount -uw /mnt/app 2>/dev/null; then rm -f "$TURN_TEXT_FILE"; mount -ur /mnt/app 2>/dev/null || true; fi
    fi
fi

# ---- Audi MIB2 AU37x: cover art and route guidance on the cluster --------
# CarPlay (chefranov's mhi2-au37x-carplay jars): patch Audi stock classes
#   AppConnectorTerminalMode and ClusterService for CarPlay data (file path,
#   RGI system). Android Auto (built from java/androidadio/): uses OSGi service
#   lookup to call AppConnectorMedia/IPictureManager/ClusterService directly
#   for DSIAndroidAuto2 data. CarPlay jars patch classes; AA jars use services,
#   so both can be loaded simultaneously on the same unit.
#
# coverart_hook.jar   - CarPlay cover art + track info (patches AppConnectorTerminalMode)
# rgd_hook.jar        - CarPlay turn arrows + distance + road name (patches ClusterService)
# AAcoverart_hook.jar - Android Auto cover art + track info (uses OSGi services)
# AArgd_hook.jar      - Android Auto turn arrows + distance + road name (uses OSGi services)
#
# Within each pair, the turns jar already carries cover art, so cover is
# redundant when turns is enabled. Across pairs, CarPlay and Android Auto
# can both be enabled at the same time.
AUDI_INFO_OK=0
if train_has "$PROFILES" "$TRAIN" info; then AUDI_INFO_OK=1; fi
if [ "$AUDI_INFO_OK" -eq 1 ]; then
    AUDI_COVER_ASKED=`sed -n 's/^CLUSTERMAP_AUDI_COVER=\([01]\)[ 	]*$/\1/p' "$CONF_FILE" 2>/dev/null | tail -1`
    AUDI_TURNS_ASKED=`sed -n 's/^CLUSTERMAP_AUDI_TURNS=\([01]\)[ 	]*$/\1/p' "$CONF_FILE" 2>/dev/null | tail -1`
    AA_COVER_ASKED=`sed -n 's/^CLUSTERMAP_AA_COVER=\([01]\)[ 	]*$/\1/p' "$CONF_FILE" 2>/dev/null | tail -1`
    AA_TURNS_ASKED=`sed -n 's/^CLUSTERMAP_AA_TURNS=\([01]\)[ 	]*$/\1/p' "$CONF_FILE" 2>/dev/null | tail -1`

    AUDI_COVER_JAR=coverart_hook.jar
    AUDI_TURNS_JAR=rgd_hook.jar
    AA_COVER_JAR=AAcoverart_hook.jar
    AA_TURNS_JAR=AArgd_hook.jar

    # Within-pair: turns jar already includes cover art, cover is redundant.
    if [ "$AUDI_TURNS_ASKED" = 1 ] && [ "$AUDI_COVER_ASKED" = 1 ]; then
        echo "WARNING: CLUSTERMAP_AUDI_COVER=1 ignored: CLUSTERMAP_AUDI_TURNS=1 (rgd_hook.jar already includes cover art)." >&2
        AUDI_COVER_ASKED=0
    fi
    if [ "$AA_TURNS_ASKED" = 1 ] && [ "$AA_COVER_ASKED" = 1 ]; then
        echo "WARNING: CLUSTERMAP_AA_COVER=1 ignored: CLUSTERMAP_AA_TURNS=1 (AArgd_hook.jar already includes cover art)." >&2
        AA_COVER_ASKED=0
    fi

    # Each entry: jar|marker|description|asked
    AUDI_JAR_ENTRIES="
$AUDI_COVER_JAR|/mnt/app/eso/hmi/lsd/.aacluster_cover_added|CarPlay cover art and track info on the media screen|$AUDI_COVER_ASKED
$AUDI_TURNS_JAR|/mnt/app/eso/hmi/lsd/.aacluster_audi_turns_added|CarPlay turn arrows, distance and road name on the cluster|$AUDI_TURNS_ASKED
$AA_COVER_JAR|/mnt/app/eso/hmi/lsd/.aacluster_aa_cover_added|Android Auto cover art and track info on the media screen|$AA_COVER_ASKED
$AA_TURNS_JAR|/mnt/app/eso/hmi/lsd/.aacluster_aa_turns_added|Android Auto turn arrows, distance and road name on the cluster|$AA_TURNS_ASKED
"

    # Remove jars not asked for.
    echo "$AUDI_JAR_ENTRIES" | while IFS='|' read -r AJAR AMARKER AWHAT AASKED; do
        [ -z "$AJAR" ] && continue
        [ "$AASKED" = 1 ] && continue
        if sh "$CARD_ROOT/lsd_jar.sh" loaded $AJAR; then
            if [ -f "$AMARKER" ]; then
                echo "Java check: removing $AJAR (not asked for in gal_dualscreen.conf)."
                if sh "$CARD_ROOT/lsd_jar.sh" remove $AJAR; then
                    mount -uw /mnt/app 2>/dev/null && { rm -f "$AMARKER"; mount -ur /mnt/app 2>/dev/null || true; }
                else
                    echo "WARNING: could not remove $AJAR; lsd.sh is unchanged." >&2
                fi
            else
                echo "WARNING: $AJAR is loaded and this installer did not add it." >&2
            fi
        fi
    done

    # Add/update asked-for jars.
    echo "$AUDI_JAR_ENTRIES" | while IFS='|' read -r AJAR AMARKER AWHAT AASKED; do
        [ -z "$AJAR" ] && continue
        [ "$AASKED" = 1 ] || continue
        if sh "$CARD_ROOT/lsd_jar.sh" loaded $AJAR; then
            echo "Java check: $AJAR is loaded ($AWHAT)."
            sh "$CARD_ROOT/lsd_jar.sh" add $AJAR "$CARD_ROOT/thirdparty/$AJAR" ||
                echo "WARNING: could not update $AJAR; the loaded copy stays." >&2
        else
            echo "Java check: adding $AJAR ($AWHAT)."
            if sh "$CARD_ROOT/lsd_jar.sh" add $AJAR "$CARD_ROOT/thirdparty/$AJAR"; then
                mount -uw /mnt/app 2>/dev/null && { : > "$AMARKER"; mount -ur /mnt/app 2>/dev/null || true; }
            else
                echo "WARNING: could not add $AJAR; lsd.sh is unchanged." >&2
            fi
        fi
    done
fi

# ---- CarPlay map: the steering-wheel roller zooms it (AU57x cockpit) --------
# ClusterMapWheelZoom.jar replaces one small class of the stock navigation
# (the cockpit map's zoom timer), so a roller step goes to the CarPlay map
# while that covers the cockpit; libcarplay_cluster.so turns it into CarPlay's
# changeMapZoomLevel. A replaced class that does not fit the HMI stops the
# navigation, so it is added only where profiles.conf says "wheelzoom" AND
# lsd.jxe is the exact build it was checked against (tests/wheelzoom_check.sh).
# The Chinese K1006_2 has another navigation (de/audi/tghu/navasia), so
# "navasiazoom" there adds ClusterMapNavAsiaZoom.jar instead: a copy of the
# stock NavAsiaModelListener (tests/navasiazoom_check.sh) that logs each
# roller step's id and sends only the roller's (model 82137 in that lsd.jxe,
# from a car's log) to CarPlay.
#   CLUSTERMAP_CARPLAY_WHEEL_ZOOM=auto (default) | reverse | 0
#   CLUSTERMAP_CARPLAY_WHEEL_ZOOM_ID=<number> (navasiazoom only; default 82137)
WHEELZOOM_REVERSE=$PRELOAD_WRITE_DIR/wheel_zoom_reverse
WHEELZOOM_ID_FILE=$PRELOAD_WRITE_DIR/wheel_zoom_id
WZ=`sed -n 's/^CLUSTERMAP_CARPLAY_WHEEL_ZOOM=\([a-z0-9]*\)[ 	]*$/\1/p' \
    "$PRELOAD_WRITE_DIR/gal_dualscreen.conf" 2>/dev/null | tail -1`
case "$WZ" in
    ''|auto|1) WZ=auto ;;
    reverse|0) ;;
    *) echo "CarPlay map: CLUSTERMAP_CARPLAY_WHEEL_ZOOM=$WZ not understood (auto, reverse or 0); using auto"
       WZ=auto ;;
esac
WZ_ID=`sed -n 's/^CLUSTERMAP_CARPLAY_WHEEL_ZOOM_ID=\([0-9]*\)[ 	]*$/\1/p' \
    "$PRELOAD_WRITE_DIR/gal_dualscreen.conf" 2>/dev/null | tail -1`
WZ_LSD=`file_size /ifs/lsd.jxe`
WZ_NAME=
if train_has "$PROFILES" "$TRAIN" wheelzoom; then
    WZ_NAME=wheelzoom WHEELZOOM_JAR=ClusterMapWheelZoom.jar WHEELZOOM_LSD_SIZE=44688282
    WZ_ID=   # the roller id is for navasiazoom only
elif train_has "$PROFILES" "$TRAIN" navasiazoom; then
    WZ_NAME=navasiazoom WHEELZOOM_JAR=ClusterMapNavAsiaZoom.jar WHEELZOOM_LSD_SIZE=43229093
    WZ_ID=${WZ_ID:-82137}
fi
WZ_WHY=
if [ "$WZ" = 0 ]; then
    WZ_WHY="turned off (CLUSTERMAP_CARPLAY_WHEEL_ZOOM=0)"
elif [ "$CARPLAY_OK" -ne 1 ]; then
    WZ_WHY="the CarPlay map is not installed"
elif [ -z "$WZ_NAME" ]; then
    WZ_WHY="not made for $TRAIN"
elif [ "$WZ_LSD" != "$WHEELZOOM_LSD_SIZE" ]; then
    WZ_WHY="this unit's interface (lsd.jxe, ${WZ_LSD:-unreadable} bytes) is not the $WHEELZOOM_LSD_SIZE-byte build it was made for"
elif [ ! -r "$CARD_ROOT/carplay/$WHEELZOOM_JAR" ] || [ ! -r "$LSD_SH" ] || [ ! -r "$CARD_ROOT/lsd_jar.sh" ]; then
    WZ_WHY="its files are not in this package"
fi
# Taken out again only where this installer put it: any zoom jar but the one
# that fits now.
for WZ_EXTRA in wheelzoom:ClusterMapWheelZoom.jar navasiazoom:ClusterMapNavAsiaZoom.jar; do
    WZ_OLD=${WZ_EXTRA%%:*}
    WZ_OLD_JAR=${WZ_EXTRA#*:}
    WZ_OLD_MARKER=/mnt/app/eso/hmi/lsd/.aacluster_${WZ_OLD}_added
    [ -z "$WZ_WHY" ] && [ "$WZ_OLD" = "$WZ_NAME" ] && continue
    if [ -f "$WZ_OLD_MARKER" ] && sh "$CARD_ROOT/lsd_jar.sh" loaded $WZ_OLD_JAR; then
        if sh "$CARD_ROOT/lsd_jar.sh" remove $WZ_OLD_JAR; then
            if mount -uw /mnt/app 2>/dev/null; then rm -f "$WZ_OLD_MARKER" "$WHEELZOOM_REVERSE" "$WHEELZOOM_ID_FILE"; mount -ur /mnt/app 2>/dev/null || true; fi
        else
            echo "WARNING: could not remove $WZ_OLD_JAR; lsd.sh is unchanged." >&2
        fi
    fi
done
if [ -z "$WZ_WHY" ]; then
    if sh "$CARD_ROOT/lsd_jar.sh" add $WHEELZOOM_JAR "$CARD_ROOT/carplay/$WHEELZOOM_JAR"; then
        if mount -uw /mnt/app 2>/dev/null; then
            : > "/mnt/app/eso/hmi/lsd/.aacluster_${WZ_NAME}_added"
            if [ "$WZ" = reverse ]; then : > "$WHEELZOOM_REVERSE"; else rm -f "$WHEELZOOM_REVERSE"; fi
            if [ "$WZ_NAME" = navasiazoom ] && [ -n "$WZ_ID" ]; then
                echo "$WZ_ID" > "$WHEELZOOM_ID_FILE"
            else
                rm -f "$WHEELZOOM_ID_FILE"
            fi
            mount -ur /mnt/app 2>/dev/null || true
        fi
        echo "CarPlay map: steering-wheel zoom on${WZ:+ ($WZ)}${WZ_ID:+, roller id $WZ_ID}: the roller zooms the CarPlay map while it is on the cockpit."
    else
        echo "WARNING: could not add $WHEELZOOM_JAR; lsd.sh is unchanged. The roller zooms the stock map only." >&2
    fi
else
    case "$TRAIN" in
        *_AU57x_*) echo "CarPlay map: steering-wheel zoom not installed, $WZ_WHY." ;;
    esac
fi

# ---- CarPlay map: keep it when the iPhone starts a route --------------------
# CLUSTERMAP_CARPLAY_HIDE_NAV=1: the CarPlay hook does not pass on to the car
# that the iPhone has started a route (libcarplay_cluster.so reads the marker
# file each time). For cars whose cockpit leaves the map during a CarPlay
# route although the stream keeps running (US P3662, #10). Off by default,
# except on a train with the "hidenav" word in profiles.conf (VW VWG11, where
# NavActiveIgnore stops CarPlay connecting: car-tested on a K3342, #111);
# CLUSTERMAP_CARPLAY_HIDE_NAV=0 turns it off there too.
HIDE_NAV_MARKER=$PRELOAD_WRITE_DIR/carplay_hide_nav
HIDE_NAV=`sed -n 's/^CLUSTERMAP_CARPLAY_HIDE_NAV=\([01]\)[ 	]*$/\1/p' \
    "$PRELOAD_WRITE_DIR/gal_dualscreen.conf" 2>/dev/null | tail -1`
HIDE_NAV_WHY="CLUSTERMAP_CARPLAY_HIDE_NAV=1"
if [ -z "$HIDE_NAV" ] && train_has "$PROFILES" "$TRAIN" hidenav; then
    HIDE_NAV=1
    HIDE_NAV_WHY="the default on $TRAIN; CLUSTERMAP_CARPLAY_HIDE_NAV=0 turns it off"
fi
if mount -uw "$APP_MOUNT" 2>/dev/null; then
    if [ "$HIDE_NAV" = 1 ] && [ "$CARPLAY_OK" -eq 1 ]; then
        : > "$HIDE_NAV_MARKER"
        echo "CarPlay map: the iPhone's route is hidden from the car, so the cockpit keeps the map ($HIDE_NAV_WHY)."
    else
        rm -f "$HIDE_NAV_MARKER"
    fi
    mount -ur "$APP_MOUNT" 2>/dev/null || true
fi

# The install is complete: remember which package and which card file it
# was, for the settings comparison at the next install. Not earlier, so a
# run that failed part-way is not taken for a finished install of this card.
if mount -uw "$APP_MOUNT" 2>/dev/null; then
    if [ -n "$CARD_SAVED_NEW" ] && [ -r "$CARD_LAST.new" ]; then
        mv "$CARD_LAST.new" "$CARD_LAST" 2>/dev/null || rm -f "$CARD_LAST.new" 2>/dev/null
    fi
    if [ -n "$PKG_NOW" ]; then
        echo "$PKG_NOW" > "$PKG_SAVED" 2>/dev/null || :
    fi
    mount -ur "$APP_MOUNT" 2>/dev/null || true
fi

echo
echo "Reboot the unit to apply it. Do not start a second GAL manually."
