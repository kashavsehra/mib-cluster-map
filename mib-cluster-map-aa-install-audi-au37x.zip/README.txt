Android Auto install package for Audi MIB2 AU37x
See thirdparty/VCAndroidAuto_Audi.LICENSE for details.
