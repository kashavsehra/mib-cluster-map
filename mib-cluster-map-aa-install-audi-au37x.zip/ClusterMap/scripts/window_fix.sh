#!/bin/sh
# Started by the player when the cockpit's map window is not the size in the
# settings: window_fix.sh WIDTH HEIGHT. Corrects the installed settings, so the
# phone is asked for the right shape from the next start. It only changes
# the window lines the installer wrote, through lib_cluster_frame.sh, which
# the installer copies next to this script, and saves the size in
# player_window there, which the next install uses when the display manager
# does not list the window (#95).
# /mnt/app/armle/usr/bin holds dirname and other tools: without it
# this script never found its library (#95).
PATH=/proc/boot:/bin:/usr/bin:/usr/sbin:/sbin:/mnt/app/armle/bin:/mnt/app/armle/sbin:/mnt/app/armle/usr/bin:/mnt/app/armle/usr/sbin:$PATH
export PATH
W=$1
H=$2
case "$W$H" in ''|*[!0-9]*) exit 2 ;; esac
LOG=/tmp/stream-player.log
# The player starts it by its full path; ${0%/*} needs no program.
HERE=${0%/*}
[ "$HERE" = "$0" ] && HERE=.
LIB="$HERE/lib_cluster_frame.sh"
if [ ! -r "$LIB" ]; then
    echo "window_fix: ${W}x${H} not written: $LIB missing (install again)" >> $LOG
    exit 1
fi
. "$LIB"
CONF=/mnt/app/eso/lib/gal_dualscreen/gal_dualscreen.conf
FULL=`sed -n 's/^CLUSTERMAP_FULL_FRAME=\([01]\)[ 	]*$/\1/p' "$CONF" | tail -1`
[ "$FULL" = 1 ] || FULL=0
HD720=`sed -n 's/^CLUSTERMAP_720P=\([01]\)[ 	]*$/\1/p' "$CONF" | tail -1`
[ "$HD720" = 1 ] || HD720=0
HD1080=`sed -n 's/^CLUSTERMAP_1080P=\([01]\)[ 	]*$/\1/p' "$CONF" | tail -1`
[ "$HD1080" = 1 ] || HD1080=0
# Leave /mnt/app as it was found: an install, the Java script editor or the
# sharper-map switch can have it writable at this moment, and remounting it
# read-only under them fails their next write. While one of them is at
# work (their .new files), wait for the next start of the player.
if [ -e "$CONF.new" ] || [ -e /mnt/app/eso/hmi/lsd/lsd.sh.jar_new ]; then
    echo "window_fix: ${W}x${H} not written: an install is running" >> $LOG
    exit 1
fi
MOUNTED=0
if [ ! -w "$CONF" ]; then
    if mount -uw /mnt/app 2>/dev/null; then MOUNTED=1; fi
fi
frame_write_conf "$CONF" "$W" "$H" "$FULL" "$HD720" "$HD1080"
RC=$?
# Kept for the next install, which rewrites the settings from the card.
echo "${W}x${H}" > "$HERE/player_window" 2>/dev/null || echo "window_fix: could not save player_window" >> $LOG
if [ "$MOUNTED" -eq 1 ]; then mount -ur /mnt/app 2>/dev/null; fi
echo "window_fix: ${W}x${H} frame ${FRAME_W}x${FRAME_H} margins ${MARGIN_W}x${MARGIN_H} pixel_aspect_e4 ${PIXEL_ASPECT_E4} rc=$RC" >> $LOG
exit $RC
