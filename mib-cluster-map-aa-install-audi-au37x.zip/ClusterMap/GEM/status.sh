#!/bin/sh
. "`dirname "$0"`/common.sh"
CONFIG=/mnt/system/etc/eso/production/smartphone_integrator.json
LSD=/mnt/app/eso/hmi/lsd/lsd.sh
echo "Phone map on the digital cluster: status"
echo "Package folder: $PKG"
echo "Firmware train: $TRAIN"
if train_supported; then echo "  supported: yes ($SUPPORT_NOTE)"; else echo "  supported: NO ($SUPPORT_NOTE)"; fi
if grep -q 'libgal_hook.so' "$CONFIG" 2>/dev/null; then echo "Hook: installed"; else echo "Hook: not installed"; fi
if [ -f /mnt/app/eso/lib/gal_dualscreen/libgal_hook.so ]; then echo "  library: present"; else echo "  library: missing"; fi
if [ -f /mnt/app/navigation/stream-player ]; then echo "  player: present"; else echo "  player: missing"; fi
UC=/mnt/app/eso/lib/gal_dualscreen/gal_dualscreen.conf
if [ -r "$UC" ]; then
    echo "Switches (ClusterMapOptions, ClusterMapPicture):"
    for k in GAL_PLAYER_DECODER GAL_PLAYER_REASSERT GAL_DUALSCREEN_ENABLE GAL_SECONDARY_UI_THEME CLUSTERMAP_FULL_FRAME GAL_PLAYER_STATS; do
        v=`sed -n "s/^[ 	]*$k[ 	]*=[ 	]*\([^ 	]*\)[ 	]*\$/\1/p" "$UC" | sed -n '1p'`
        echo "  $k=${v:-(not set)}"
    done
fi
echo "Hardware decoder libraries:"
hw_libs
if [ -f /mnt/app/navigation/opengl-render-qnx ] || pidin ar 2>/dev/null | grep opengl-render-qnx >/dev/null 2>&1; then
    echo "WARNING: an older cluster renderer (opengl-render-qnx) is installed or running."
    echo "  It takes the cockpit window the map uses (#105). Install again to switch it off."
elif [ -f /mnt/app/navigation/opengl-render-qnx.clustermap-off ]; then
    echo "Older cluster renderer: switched off by the install (the uninstall puts it back)."
fi
for f in /fs/sda0/gal_dualscreen.conf /fs/sdb0/gal_dualscreen.conf; do
    if [ -f "$f" ]; then echo "WARNING: $f overrides the installed settings while that card is in."; fi
done
if [ -r "$UC" ]; then
    if grep -q '^CLUSTERMAP_1080P=1' "$UC"; then
        echo "Android Auto picture: 1080p test (1920x1080)"
    elif grep -q '^CLUSTERMAP_720P=1' "$UC"; then
        echo "Android Auto picture: 720p test (1280x720)"
    elif grep -q '^CLUSTERMAP_FULL_FRAME=1' "$UC"; then
        echo "Android Auto picture: 800x480 full frame"
    else
        echo "Android Auto picture: standard 800x480"
    fi
fi
if grep -q 'libcarplay_cluster.so' "$CONFIG" 2>/dev/null; then
    echo "CarPlay map: installed, `sed -n 's/.*"ALTSCREEN111_WIDTH=\([0-9]*\)", "ALTSCREEN111_HEIGHT=\([0-9]*\)".*/\1x\2/p' "$CONFIG"`"
    if [ -r /tmp/mibr-carplay111.state ]; then echo "  CarPlay cluster stream: `cat /tmp/mibr-carplay111.state`"; else echo "  CarPlay cluster stream: none yet (connect an iPhone)"; fi
    if sh "$PKG/lsd_jar.sh" loaded ClusterMapWheelZoom.jar; then
        if [ -f /mnt/app/eso/lib/gal_dualscreen/wheel_zoom_reverse ]; then echo "  steering-wheel zoom: loaded, reversed"; else echo "  steering-wheel zoom: loaded"; fi
        if [ -r /tmp/clustermap-wheelzoom.log ]; then tail -2 /tmp/clustermap-wheelzoom.log | sed 's/^/    /'; fi
    elif sh "$PKG/lsd_jar.sh" loaded ClusterMapNavAsiaZoom.jar; then
        if [ -r /mnt/app/eso/lib/gal_dualscreen/wheel_zoom_id ]; then echo "  steering-wheel zoom: loaded, roller id `cat /mnt/app/eso/lib/gal_dualscreen/wheel_zoom_id`"
        else echo "  steering-wheel zoom: loaded, log only (no roller id set)"; fi
        [ -f /mnt/app/eso/lib/gal_dualscreen/wheel_zoom_reverse ] && echo "    reversed"
        if [ -r /tmp/clustermap-wheelzoom.log ]; then tail -4 /tmp/clustermap-wheelzoom.log | sed 's/^/    /'; fi
    fi
else
    # The library is not in the same folder on every unit: found as the
    # installer finds it (common.sh).
    ap=`airplay_path`
    a=
    if [ -n "$ap" ]; then a=`wc -c < "$ap" 2>/dev/null | sed 's/ //g'`; fi
    if [ "$a" = 703688 ] || [ "$a" = 694088 ]; then echo "CarPlay map: not installed (this unit's CarPlay library is supported)"
    elif [ -n "$a" ]; then echo "CarPlay map: not installed (CarPlay library $a bytes; tested: 703688 and 694088. Another build needs CLUSTERMAP_CARPLAY_TRIAL, see Install)"
    else echo "CarPlay map: not installed (no CarPlay library found on this unit)"; fi
fi
if sh "$PKG/lsd_jar.sh" loaded NavActiveIgnore.jar; then echo "NavActiveIgnore: loaded (required)"
elif sh "$PKG/lsd_jar.sh" loaded CarPlayNavigationPatch.jar; then echo "NavActiveIgnore: loaded as CarPlay's CarPlayNavigationPatch.jar (same patch)"
else echo "NavActiveIgnore: not loaded (Install adds it on tested firmware)"; fi
if sh "$PKG/lsd_jar.sh" loaded VCAndroidAuto.jar; then echo "Turn-by-turn arrows (VCAndroidAuto.jar): loaded. Installing the map turns this off."; else echo "Turn-by-turn arrows (VCAndroidAuto.jar): not loaded"; fi
echo "Java patch lines:"
grep -n 'Xbootclasspath/p' "$LSD" 2>/dev/null | sed 's|.*/p:||; s|\$BASE_DIR/lsd/jars/||g; s|"$||; s|^|  |'
if [ -r /tmp/gal_dualscreen.log ]; then
    echo "Last hook events:"
    grep -E "event=(init |firmware.verify|secondary.register|focus.state|player.spawn|focus.loss)" /tmp/gal_dualscreen.log | tail -6 | sed -e 's/^gal_dualscreen //' -e 's/^\(.\{110\}\).*/\1/'
else
    echo "No hook log yet (connect a phone after rebooting)."
fi
exit 0
